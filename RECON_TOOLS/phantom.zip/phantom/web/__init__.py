from flask import Flask
from flask_login import LoginManager
from core.db import db, User
from core.config import config
from core.logger import logger
from pathlib import Path

login_manager = LoginManager()


def create_app():
    app = Flask(__name__)
    app.config["SECRET_KEY"] = "change-this-in-production"
    app.config["SQLALCHEMY_DATABASE_URI"] = config.database_url
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = "auth.login"

    from web.auth.routes import auth_bp
    from web.dashboard.routes import dashboard_bp
    from web.targets.routes import targets_bp
    from web.scans.routes import scans_bp
    from web.results.routes import results_bp
    from web.notes.routes import notes_bp
    from web.export.routes import export_bp
    from web.api.routes import api_bp

    app.register_blueprint(auth_bp, url_prefix="/auth")
    app.register_blueprint(dashboard_bp, url_prefix="/")
    app.register_blueprint(targets_bp, url_prefix="/targets")
    app.register_blueprint(scans_bp, url_prefix="/scans")
    app.register_blueprint(results_bp, url_prefix="/results")
    app.register_blueprint(notes_bp, url_prefix="/notes")
    app.register_blueprint(export_bp, url_prefix="/export")
    app.register_blueprint(api_bp, url_prefix="/api")

    with app.app_context():
        db.create_all()

    return app


@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))
