from flask import Blueprint, render_template, redirect, url_for, request, jsonify
from flask_login import login_required
from core.db import db, Target, Scan, ScanResult
from core.engine import engine
import json

scans_bp = Blueprint("scans", __name__)


@scans_bp.route("/")
@login_required
def index():
    scans = Scan.query.order_by(Scan.created_at.desc()).all()
    return render_template("scans/index.html", scans=scans)


@scans_bp.route("/run", methods=["GET", "POST"])
@login_required
def run():
    targets = Target.query.all()
    modules = engine.list_modules()
    if request.method == "POST":
        target_id = request.form.get("target_id")
        selected_modules = request.form.getlist("modules")
        target = db.session.get(Target, int(target_id))
        if target and selected_modules:
            scan = Scan(target_id=target.id, modules=",".join(selected_modules), status="pending")
            db.session.add(scan)
            db.session.commit()
            engine.start_scan(scan.id, selected_modules)
            return redirect(url_for("scans.detail", scan_id=scan.id))
    return render_template("scans/run.html", targets=targets, modules=modules)


@scans_bp.route("/<int:scan_id>")
@login_required
def detail(scan_id):
    scan = db.session.get(Scan, scan_id)
    if not scan:
        return "Scan not found", 404
    results = ScanResult.query.filter_by(scan_id=scan_id).order_by(ScanResult.created_at.desc()).all()
    return render_template("scans/detail.html", scan=scan, results=results)


@scans_bp.route("/<int:scan_id>/cancel", methods=["POST"])
@login_required
def cancel(scan_id):
    engine.cancel_scan(scan_id)
    return redirect(url_for("scans.detail", scan_id=scan_id))
