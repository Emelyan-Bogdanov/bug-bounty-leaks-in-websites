document.addEventListener('DOMContentLoaded', function() {
  const navLinks = document.querySelectorAll('.sidebar nav a');
  const currentPath = window.location.pathname;

  navLinks.forEach(link => {
    if (link.getAttribute('href') === currentPath ||
        (currentPath.startsWith(link.getAttribute('href')) && link.getAttribute('href') !== '/')) {
      link.classList.add('active');
    }
  });

  const hamburger = document.querySelector('.hamburger');
  if (hamburger) {
    hamburger.addEventListener('click', function() {
      document.querySelector('.sidebar').classList.toggle('collapsed');
    });
  }

  const severityFilters = document.querySelectorAll('.severity-filter');
  severityFilters.forEach(btn => {
    btn.addEventListener('click', function() {
      const severity = this.dataset.severity;
      const rows = document.querySelectorAll('.result-row');
      rows.forEach(row => {
        if (severity === 'all' || row.dataset.severity === severity) {
          row.style.display = '';
        } else {
          row.style.display = 'none';
        }
      });
      severityFilters.forEach(b => b.classList.remove('active'));
      this.classList.add('active');
    });
  });

  const liveOutput = document.getElementById('live-output');
  if (liveOutput) {
    const eventSource = new EventSource('/api/stream');
    eventSource.onmessage = function(event) {
      const div = document.createElement('div');
      div.textContent = event.data;
      liveOutput.appendChild(div);
      liveOutput.scrollTop = liveOutput.scrollHeight;
    };
  }

  const confirmButtons = document.querySelectorAll('[data-confirm]');
  confirmButtons.forEach(btn => {
    btn.addEventListener('click', function(e) {
      if (!confirm(this.dataset.confirm || 'Are you sure?')) {
        e.preventDefault();
      }
    });
  });
});
