from flask import Blueprint, render_template, request
from flask_login import login_required
from core.db import db, ScanResult

results_bp = Blueprint("results", __name__)


@results_bp.route("/")
@login_required
def index():
    severity = request.args.get("severity", "")
    module = request.args.get("module", "")
    query = ScanResult.query
    if severity:
        query = query.filter_by(severity=severity)
    if module:
        query = query.filter_by(module=module)
    results = query.order_by(ScanResult.created_at.desc()).all()
    modules = [r[0] for r in ScanResult.query.with_entities(ScanResult.module).distinct().all()]
    return render_template("results/index.html", results=results, modules=modules)
