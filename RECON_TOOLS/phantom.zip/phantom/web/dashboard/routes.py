from flask import Blueprint, render_template
from flask_login import login_required
from core.db import db, Target, Scan, ScanResult, Note

dashboard_bp = Blueprint("dashboard", __name__)


@dashboard_bp.route("/")
@login_required
def index():
    total_targets = Target.query.count()
    active_scans = Scan.query.filter_by(status="running").count()
    total_results = ScanResult.query.count()
    critical_findings = ScanResult.query.filter_by(severity="critical").count()
    recent_scans = Scan.query.order_by(Scan.created_at.desc()).limit(10).all()
    recent_targets = Target.query.order_by(Target.created_at.desc()).limit(5).all()

    return render_template(
        "dashboard/index.html",
        total_targets=total_targets,
        active_scans=active_scans,
        total_results=total_results,
        critical_findings=critical_findings,
        recent_scans=recent_scans,
        recent_targets=recent_targets,
    )
