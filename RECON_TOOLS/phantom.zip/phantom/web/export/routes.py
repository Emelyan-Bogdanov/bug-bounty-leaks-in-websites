from flask import Blueprint, render_template, redirect, url_for, request, send_file
from flask_login import login_required
from core.db import db, Target
from pathlib import Path
import asyncio

export_bp = Blueprint("export", __name__)


@export_bp.route("/")
@login_required
def index():
    targets = Target.query.all()
    return render_template("reports/index.html", targets=targets)


@export_bp.route("/generate", methods=["POST"])
@login_required
def generate():
    target_id = request.form.get("target_id")
    fmt = request.form.get("format", "html")
    target = db.session.get(Target, int(target_id))
    if not target:
        return "Target not found", 404

    format_map = {
        "html": "modules.reporting.html_report",
        "pdf": "modules.reporting.pdf_report",
        "csv": "modules.reporting.csv_export",
        "json": "modules.reporting.json_export",
    }
    import importlib
    mod = importlib.import_module(format_map[fmt])
    results = asyncio.run(mod.run(target.id))
    path = results[0].get("url", "")
    if path and Path(path).exists():
        return send_file(path, as_attachment=True)
    return redirect(url_for("export.index"))
