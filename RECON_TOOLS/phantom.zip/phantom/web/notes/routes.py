from flask import Blueprint, render_template, redirect, url_for, request
from flask_login import login_required, current_user
from core.db import db, Note, Target

notes_bp = Blueprint("notes", __name__)


@notes_bp.route("/")
@login_required
def index():
    target_id = request.args.get("target_id")
    if target_id:
        notes = Note.query.filter_by(target_id=int(target_id)).order_by(Note.created_at.desc()).all()
    else:
        notes = Note.query.order_by(Note.created_at.desc()).all()
    targets = Target.query.all()
    return render_template("notes/index.html", notes=notes, targets=targets)


@notes_bp.route("/add", methods=["POST"])
@login_required
def add():
    target_id = request.form.get("target_id")
    content = request.form.get("content")
    tags = request.form.get("tags", "")
    if target_id and content:
        note = Note(target_id=int(target_id), user_id=current_user.id, content=content, tags=tags)
        db.session.add(note)
        db.session.commit()
    return redirect(url_for("notes.index", target_id=target_id))
