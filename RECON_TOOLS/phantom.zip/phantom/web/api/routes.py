from flask import Blueprint, jsonify, request
from core.db import db, Target, Scan, ScanResult, Note
from core.engine import engine

api_bp = Blueprint("api", __name__)


@api_bp.route("/targets")
def api_targets():
    targets = Target.query.all()
    return jsonify([{"id": t.id, "name": t.name, "domain": t.domain, "type": t.type, "status": t.status} for t in targets])


@api_bp.route("/targets/<int:target_id>")
def api_target(target_id):
    target = db.session.get(Target, target_id)
    if not target:
        return jsonify({"error": "not found"}), 404
    return jsonify({"id": target.id, "name": target.name, "domain": target.domain, "ip": target.ip, "type": target.type, "status": target.status})


@api_bp.route("/scans")
def api_scans():
    scans = Scan.query.order_by(Scan.created_at.desc()).limit(50).all()
    return jsonify([{"id": s.id, "target_id": s.target_id, "modules": s.modules, "status": s.status} for s in scans])


@api_bp.route("/results")
def api_results():
    target_id = request.args.get("target_id")
    severity = request.args.get("severity")
    query = ScanResult.query
    if target_id:
        query = query.filter_by(target_id=int(target_id))
    if severity:
        query = query.filter_by(severity=severity)
    results = query.order_by(ScanResult.created_at.desc()).limit(100).all()
    return jsonify([{
        "id": r.id, "module": r.module, "finding_type": r.finding_type,
        "severity": r.severity, "url": r.url, "parameter": r.parameter,
        "payload": r.payload, "evidence": r.evidence,
    } for r in results])


@api_bp.route("/scans/start", methods=["POST"])
def api_start_scan():
    data = request.json
    target_id = data.get("target_id")
    modules = data.get("modules", [])
    target = db.session.get(Target, int(target_id))
    if not target:
        return jsonify({"error": "target not found"}), 404
    scan = Scan(target_id=target.id, modules=",".join(modules), status="pending", triggered_by="api")
    db.session.add(scan)
    db.session.commit()
    engine.start_scan(scan.id, modules)
    return jsonify({"scan_id": scan.id, "status": "started"})
