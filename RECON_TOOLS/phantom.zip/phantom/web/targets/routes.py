from flask import Blueprint, render_template, redirect, url_for, request, jsonify
from flask_login import login_required
from core.db import db, Target, Scan, ScanResult, Note
from core.utils import normalize_target

targets_bp = Blueprint("targets", __name__)


@targets_bp.route("/")
@login_required
def index():
    targets = Target.query.order_by(Target.created_at.desc()).all()
    return render_template("targets/index.html", targets=targets)


@targets_bp.route("/<int:target_id>")
@login_required
def detail(target_id):
    target = db.session.get(Target, target_id)
    if not target:
        return "Target not found", 404
    scans = Scan.query.filter_by(target_id=target_id).order_by(Scan.created_at.desc()).all()
    notes = Note.query.filter_by(target_id=target_id).order_by(Note.created_at.desc()).all()
    results = ScanResult.query.filter_by(target_id=target_id).order_by(ScanResult.created_at.desc()).limit(50).all()
    return render_template("targets/detail.html", target=target, scans=scans, notes=notes, results=results)


@targets_bp.route("/add", methods=["POST"])
@login_required
def add():
    name = request.form.get("name")
    value = request.form.get("value")
    val, ttype = normalize_target(value)
    target = Target(name=name or val, domain=val if ttype == "domain" else None, ip=val if ttype == "ip" else None, type=ttype)
    db.session.add(target)
    db.session.commit()
    return redirect(url_for("targets.index"))


@targets_bp.route("/<int:target_id>/delete", methods=["POST"])
@login_required
def delete(target_id):
    target = db.session.get(Target, target_id)
    if target:
        db.session.delete(target)
        db.session.commit()
    return redirect(url_for("targets.index"))
