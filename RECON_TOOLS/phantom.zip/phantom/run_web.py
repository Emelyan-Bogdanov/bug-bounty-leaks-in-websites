#!/usr/bin/env python3
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))

from web import create_app
from core.config import config

app = create_app()

if __name__ == "__main__":
    app.run(host=config.host, port=config.port, debug=config.debug)
