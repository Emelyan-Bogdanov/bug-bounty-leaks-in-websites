from typing import Optional
from pathlib import Path
import aiohttp
import asyncio

from core.config import config


async def _load_wordlist() -> list[str]:
    path = config.wordlists.get("directories")
    if path and Path(path).exists():
        with open(path) as f:
            return [line.strip() for line in f if line.strip()]
    return ["admin", "wp-admin", "api", "backup", "config", ".git/HEAD", "robots.txt", "sitemap.xml"]


async def run(target: str, scan_id: Optional[int] = None) -> list[dict]:
    results = []
    base = f"https://{target}" if not target.startswith("http") else target
    base = base.rstrip("/")
    wordlist = await _load_wordlist()

    sem = asyncio.Semaphore(20)
    async with aiohttp.ClientSession() as session:
        async def _check(path: str) -> dict | None:
            async with sem:
                url = f"{base}/{path}"
                try:
                    async with session.get(url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                        if resp.status not in (404, 403) and resp.status < 500:
                            return {
                                "finding_type": "Discovered Path",
                                "severity": "info",
                                "url": url,
                                "evidence": f"HTTP {resp.status} ({len(await resp.read())} bytes)",
                            }
                except Exception:
                    pass
                return None

        tasks = [_check(p) for p in wordlist]
        for coro in asyncio.as_completed(tasks):
            result = await coro
            if result:
                results.append(result)
    return results
