from typing import Optional
import aiohttp
import asyncio

VHOST_WORDLIST = [
    "admin", "dev", "staging", "api", "mail", "cdn", "www", "test",
    "beta", "app", "blog", "shop", "portal", "secure", "vpn", "intranet",
]


async def run(target: str, scan_id: Optional[int] = None) -> list[dict]:
    results = []
    base = f"https://{target}" if not target.startswith("http") else target

    sem = asyncio.Semaphore(10)
    async with aiohttp.ClientSession() as session:
        async def _check(vhost: str) -> dict | None:
            async with sem:
                try:
                    async with session.get(
                        base,
                        headers={"Host": f"{vhost}.{target}"},
                        timeout=aiohttp.ClientTimeout(total=10),
                    ) as resp:
                        if resp.status != 404:
                            return {
                                "finding_type": "Virtual Host",
                                "severity": "medium",
                                "url": base,
                                "evidence": f"vhost: {vhost}.{target} → HTTP {resp.status}",
                            }
                except Exception:
                    pass
                return None

        tasks = [_check(v) for v in VHOST_WORDLIST]
        for coro in asyncio.as_completed(tasks):
            result = await coro
            if result:
                results.append(result)
    return results
