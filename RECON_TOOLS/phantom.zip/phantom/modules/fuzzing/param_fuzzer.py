from typing import Optional
import aiohttp
from urllib.parse import urlparse, urlencode

COMMON_PARAMS = [
    "id", "page", "file", "action", "cmd", "debug", "test", "source", "dir",
    "download", "path", "read", "lang", "type", "name", "user", "password",
    "token", "redirect", "return", "url", "dest", "include", "exec",
]


async def run(target: str, scan_id: Optional[int] = None) -> list[dict]:
    results = []
    base = f"https://{target}" if not target.startswith("http") else target
    parsed = urlparse(base)

    async with aiohttp.ClientSession() as session:
        for param in COMMON_PARAMS:
            url = f"{base}?{urlencode({param: 'test'})}" if not parsed.query else f"{base}&{urlencode({param: 'test'})}"
            try:
                async with session.get(url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                    if resp.status != 404:
                        results.append({
                            "finding_type": "Hidden Parameter",
                            "severity": "info",
                            "url": url,
                            "parameter": param,
                            "evidence": f"HTTP {resp.status} — parameter accepted",
                        })
            except Exception:
                pass
    return results
