from typing import Optional
import aiohttp
import asyncio
from urllib.parse import urljoin

API_ENDPOINTS = [
    "v1", "v2", "v3", "api", "graphql", "rest", "swagger", "openapi",
    "docs", "api/v1", "api/v2", "api/rest", "api/graphql",
]

REST_PATHS = [
    "users", "admin", "config", "health", "status", "metrics", "info",
    "user", "account", "orders", "products", "items", "search", "auth",
]


async def run(target: str, scan_id: Optional[int] = None) -> list[dict]:
    results = []
    base = f"https://{target}" if not target.startswith("http") else target
    base = base.rstrip("/")

    sem = asyncio.Semaphore(15)
    async with aiohttp.ClientSession() as session:
        async def _check(endpoint: str) -> dict | None:
            async with sem:
                url = f"{base}/{endpoint}"
                try:
                    async with session.get(url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                        if resp.status != 404:
                            ct = resp.headers.get("Content-Type", "")
                            return {
                                "finding_type": "API Endpoint",
                                "severity": "info",
                                "url": url,
                                "evidence": f"HTTP {resp.status} | Content-Type: {ct}",
                            }
                except Exception:
                    pass
                return None

        all_paths = API_ENDPOINTS + [f"api/{p}" for p in REST_PATHS]
        tasks = [_check(p) for p in all_paths]
        for coro in asyncio.as_completed(tasks):
            result = await coro
            if result:
                results.append(result)

        try:
            gql_url = f"{base}/graphql"
            async with session.post(
                gql_url,
                json={"query": "{__schema{types{name}}}"},
                timeout=aiohttp.ClientTimeout(total=10),
            ) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    if "data" in data:
                        results.append({
                            "finding_type": "GraphQL Introspection",
                            "severity": "high",
                            "url": gql_url,
                            "evidence": "GraphQL introspection enabled",
                        })
        except Exception:
            pass
    return results
