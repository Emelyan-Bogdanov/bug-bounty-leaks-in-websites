from typing import Optional
import aiohttp

REQUIRED_HEADERS = {
    "Strict-Transport-Security": "Missing HSTS header — risk of SSL stripping",
    "Content-Security-Policy": "Missing CSP header — XSS mitigation reduced",
    "X-Frame-Options": "Missing X-Frame-Options — clickjacking risk",
    "X-Content-Type-Options": "Missing X-Content-Type-Options — MIME sniffing risk",
    "Referrer-Policy": "Missing Referrer-Policy — referrer leakage possible",
    "Permissions-Policy": "Missing Permissions-Policy — feature abuse possible",
}


async def run(target: str, scan_id: Optional[int] = None) -> list[dict]:
    results = []
    url = f"https://{target}" if not target.startswith("http") else target

    async with aiohttp.ClientSession() as session:
        try:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                headers = resp.headers
                for header, msg in REQUIRED_HEADERS.items():
                    val = headers.get(header, "")
                    if not val:
                        results.append({
                            "finding_type": "Missing Security Header",
                            "severity": "medium",
                            "url": url,
                            "evidence": msg,
                        })
                    elif header == "Strict-Transport-Security":
                        if "max-age" not in val.lower():
                            results.append({
                                "finding_type": "Weak HSTS",
                                "severity": "low",
                                "url": url,
                                "evidence": f"HSTS present but no max-age: {val}",
                            })
                        elif "preload" not in val.lower():
                            results.append({
                                "finding_type": "HSTS No Preload",
                                "severity": "info",
                                "url": url,
                                "evidence": "HSTS not preloaded",
                            })
                info_val = headers.get("Server", "")
                if info_val:
                    results.append({
                        "finding_type": "Server Header Disclosure",
                        "severity": "low",
                        "url": url,
                        "evidence": f"Server: {info_val}",
                    })
                x_powered = headers.get("X-Powered-By", "")
                if x_powered:
                    results.append({
                        "finding_type": "Technology Disclosure",
                        "severity": "info",
                        "url": url,
                        "evidence": f"X-Powered-By: {x_powered}",
                    })
        except Exception:
            pass
    return results
