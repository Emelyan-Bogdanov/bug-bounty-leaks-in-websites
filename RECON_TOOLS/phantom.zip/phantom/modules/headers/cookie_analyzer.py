from typing import Optional
import aiohttp
from http.cookies import SimpleCookie


async def run(target: str, scan_id: Optional[int] = None) -> list[dict]:
    results = []
    url = f"https://{target}" if not target.startswith("http") else target

    async with aiohttp.ClientSession() as session:
        try:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                set_cookie = resp.headers.get_all("Set-Cookie", [])
                for cookie_str in set_cookie:
                    cookie = SimpleCookie(cookie_str)
                    for key, morsel in cookie.items():
                        flags = []
                        if not morsel.get("secure", ""):
                            flags.append("Missing Secure flag")
                        if not morsel.get("httponly", ""):
                            flags.append("Missing HttpOnly flag")
                        same_site = morsel.get("samesite", "")
                        if not same_site:
                            flags.append("Missing SameSite attribute")
                        elif same_site.lower() == "none":
                            flags.append("SameSite=None (cross-site tracking)")
                        if not morsel.get("domain", ""):
                            flags.append("No Domain restriction")
                        if not morsel.get("path", ""):
                            flags.append("No Path restriction")
                        for flag in flags:
                            results.append({
                                "finding_type": "Cookie Security",
                                "severity": "low" if "Missing" in flag else "medium",
                                "url": url,
                                "evidence": f"Cookie '{key}': {flag}",
                            })
        except Exception:
            pass
    return results
