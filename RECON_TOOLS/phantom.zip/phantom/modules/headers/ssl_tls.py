from typing import Optional
import ssl
import socket
from datetime import datetime
from cryptography import x509
from cryptography.hazmat.backends import default_backend


async def run(target: str, scan_id: Optional[int] = None) -> list[dict]:
    results = []
    host = target.split(":")[0]
    port = 443

    try:
        context = ssl.create_default_context()
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE

        with socket.create_connection((host, port), timeout=10) as sock:
            with context.wrap_socket(sock, server_hostname=host) as ssock:
                version = ssock.version()
                cipher = ssock.cipher()
                cert_bin = ssock.getpeercert(binary_form=True)
                cert = x509.load_der_x509_certificate(cert_bin, default_backend())

                if version in ("TLSv1", "TLSv1.0", "TLSv1.1"):
                    results.append({
                        "finding_type": "Weak TLS Version",
                        "severity": "high",
                        "url": f"{host}:{port}",
                        "evidence": f"Using {version} — should be TLS 1.2+",
                    })
                else:
                    results.append({
                        "finding_type": "TLS Version",
                        "severity": "info",
                        "url": f"{host}:{port}",
                        "evidence": f"Using {version}",
                    })

                if cipher:
                    name, bits, _ = cipher
                    if bits < 128:
                        results.append({
                            "finding_type": "Weak Cipher",
                            "severity": "high",
                            "url": f"{host}:{port}",
                            "evidence": f"Cipher: {name} ({bits} bits)",
                        })

                not_after = cert.not_valid_after_utc
                if not_after and not_after < datetime.utcnow():
                    results.append({
                        "finding_type": "Expired Certificate",
                        "severity": "critical",
                        "url": f"{host}:{port}",
                        "evidence": f"Certificate expired on {not_after}",
                    })

                issuer = cert.issuer
                results.append({
                    "finding_type": "Certificate Issuer",
                    "severity": "info",
                    "url": f"{host}:{port}",
                    "evidence": str(issuer),
                })
    except Exception as e:
        results.append({
            "finding_type": "SSL/TLS Error",
            "severity": "info",
            "url": f"{host}:{port}",
            "evidence": str(e),
        })
    return results
