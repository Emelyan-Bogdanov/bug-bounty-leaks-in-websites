from typing import Optional
from pathlib import Path
from jinja2 import Template
from datetime import datetime

HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>PHANTOM Report — {{ target }}</title>
<style>
  body { font-family: -apple-system, system-ui, sans-serif; background: #0f1117; color: #e2e8f0; margin: 0; padding: 2rem; }
  .header { border-bottom: 1px solid #2a2d35; margin-bottom: 2rem; }
  .severity-critical { color: #ff4c4c; }
  .severity-high { color: #ff8c00; }
  .severity-medium { color: #f5c518; }
  .severity-low { color: #4caf50; }
  .severity-info { color: #64b5f6; }
  table { width: 100%; border-collapse: collapse; margin: 1rem 0; }
  th, td { padding: 0.5rem; text-align: left; border-bottom: 1px solid #2a2d35; }
  th { background: #1c1f26; }
  .finding { background: #1c1f26; border-radius: 8px; padding: 1rem; margin: 0.5rem 0; }
</style>
</head>
<body>
<div class="header">
  <h1>PHANTOM Security Report</h1>
  <p><strong>Target:</strong> {{ target }} | <strong>Generated:</strong> {{ date }}</p>
  <p><strong>Total Findings:</strong> {{ findings|length }}</p>
</div>

{% for sev in ['critical', 'high', 'medium', 'low', 'info'] %}
{% set items = findings|selectattr('severity', 'equalto', sev)|list %}
{% if items %}
<h2 class="severity-{{ sev }}">{{ sev|upper }} ({{ items|length }})</h2>
{% for f in items %}
<div class="finding">
  <p><strong>{{ f.finding_type }}</strong> {% if f.url %}| <code>{{ f.url }}</code>{% endif %}</p>
  <p>{{ f.evidence }}</p>
  {% if f.payload %}<p><strong>Payload:</strong> <code>{{ f.payload }}</code></p>{% endif %}
  {% if f.parameter %}<p><strong>Parameter:</strong> {{ f.parameter }}</p>{% endif %}
</div>
{% endfor %}
{% endif %}
{% endfor %}
</body>
</html>"""


async def run(target_id: int, scan_id: Optional[int] = None) -> list[dict]:
    from core.db import db, ScanResult, Target
    target = db.session.get(Target, target_id)
    if not target:
        return [{"finding_type": "Report Error", "severity": "info", "url": str(target_id), "evidence": "Target not found"}]

    results = ScanResult.query.filter_by(target_id=target_id).all()
    output_dir = Path("data/reports")
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / f"report_{target.name or target.domain}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"

    findings = []
    for r in results:
        findings.append({
            "finding_type": r.finding_type,
            "severity": r.severity,
            "url": r.url,
            "evidence": r.evidence,
            "payload": r.payload,
            "parameter": r.parameter,
        })

    tmpl = Template(HTML_TEMPLATE)
    html = tmpl.render(target=target.name or target.domain, date=datetime.now().strftime("%Y-%m-%d %H:%M:%S"), findings=findings)
    path.write_text(html)

    return [{"finding_type": "Report Generated", "severity": "info", "url": str(path), "evidence": f"HTML report saved to {path}"}]
