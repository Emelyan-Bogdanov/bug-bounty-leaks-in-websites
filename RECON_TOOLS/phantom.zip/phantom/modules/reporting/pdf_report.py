from typing import Optional
from pathlib import Path
from datetime import datetime

from .html_report import HTML_TEMPLATE
from jinja2 import Template


async def run(target_id: int, scan_id: Optional[int] = None) -> list[dict]:
    from core.db import db, ScanResult, Target
    target = db.session.get(Target, target_id)
    if not target:
        return [{"finding_type": "Report Error", "severity": "info", "url": str(target_id), "evidence": "Target not found"}]

    results = ScanResult.query.filter_by(target_id=target_id).all()
    output_dir = Path("data/reports")
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / f"report_{target.name or target.domain}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"

    findings = []
    for r in results:
        findings.append({
            "finding_type": r.finding_type,
            "severity": r.severity,
            "url": r.url,
            "evidence": r.evidence,
            "payload": r.payload,
            "parameter": r.parameter,
        })

    tmpl = Template(HTML_TEMPLATE)
    html = tmpl.render(target=target.name or target.domain, date=datetime.now().strftime("%Y-%m-%d %H:%M:%S"), findings=findings)

    try:
        from weasyprint import HTML as WeasyHTML
        WeasyHTML(string=html).write_pdf(str(path))
        return [{"finding_type": "PDF Report", "severity": "info", "url": str(path), "evidence": f"PDF report saved to {path}"}]
    except ImportError:
        return [{"finding_type": "PDF Error", "severity": "info", "url": str(target_id), "evidence": "WeasyPrint not installed"}]
