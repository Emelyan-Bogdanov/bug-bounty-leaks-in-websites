from typing import Optional
from pathlib import Path
from datetime import datetime
import csv


async def run(target_id: int, scan_id: Optional[int] = None) -> list[dict]:
    from core.db import db, ScanResult, Target
    target = db.session.get(Target, target_id)
    if not target:
        return [{"finding_type": "Export Error", "severity": "info", "url": str(target_id), "evidence": "Target not found"}]

    results = ScanResult.query.filter_by(target_id=target_id).all()
    output_dir = Path("data/reports")
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / f"report_{target.name or target.domain}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"

    with open(path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["module", "finding_type", "severity", "url", "parameter", "payload", "evidence", "created_at"])
        for r in results:
            writer.writerow([r.module, r.finding_type, r.severity, r.url, r.parameter, r.payload, r.evidence, r.created_at])

    return [{"finding_type": "CSV Export", "severity": "info", "url": str(path), "evidence": f"CSV saved to {path}"}]
