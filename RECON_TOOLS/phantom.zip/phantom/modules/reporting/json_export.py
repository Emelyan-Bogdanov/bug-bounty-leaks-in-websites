from typing import Optional
from pathlib import Path
from datetime import datetime
import json


async def run(target_id: int, scan_id: Optional[int] = None) -> list[dict]:
    from core.db import db, ScanResult, Target
    target = db.session.get(Target, target_id)
    if not target:
        return [{"finding_type": "Export Error", "severity": "info", "url": str(target_id), "evidence": "Target not found"}]

    results = ScanResult.query.filter_by(target_id=target_id).all()
    output_dir = Path("data/reports")
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / f"report_{target.name or target.domain}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"

    data = []
    for r in results:
        data.append({
            "module": r.module,
            "finding_type": r.finding_type,
            "severity": r.severity,
            "url": r.url,
            "parameter": r.parameter,
            "payload": r.payload,
            "evidence": r.evidence,
            "created_at": str(r.created_at),
        })

    payload = {
        "target": target.name or target.domain,
        "generated_at": str(datetime.now()),
        "total_findings": len(data),
        "findings": data,
    }

    path.write_text(json.dumps(payload, indent=2))
    return [{"finding_type": "JSON Export", "severity": "info", "url": str(path), "evidence": f"JSON saved to {path}"}]
