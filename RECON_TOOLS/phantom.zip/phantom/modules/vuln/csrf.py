from typing import Optional
import aiohttp
from bs4 import BeautifulSoup


async def run(target: str, scan_id: Optional[int] = None) -> list[dict]:
    results = []
    url = f"https://{target}" if not target.startswith("http") else target

    async with aiohttp.ClientSession() as session:
        try:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                text = await resp.text()
                soup = BeautifulSoup(text, "lxml")
                forms = soup.find_all("form")
                for form in forms:
                    method = form.get("method", "get").upper()
                    action = form.get("action", "")
                    full_action = url.rstrip("/") + "/" + action.lstrip("/") if action else url
                    inputs = form.find_all("input")
                    has_csrf = False
                    for inp in inputs:
                        name = inp.get("name", "").lower()
                        if any(kw in name for kw in ["csrf", "token", "nonce", "_token"]):
                            has_csrf = True
                            break
                    if method == "POST" and not has_csrf:
                        results.append({
                            "finding_type": "CSRF (Missing Token)",
                            "severity": "medium",
                            "url": full_action,
                            "evidence": f"Form at {full_action} uses POST without CSRF token",
                        })

                    same_site = resp.headers.get("Set-Cookie", "")
                    if "samesite" not in same_site.lower():
                        results.append({
                            "finding_type": "CSRF (No SameSite)",
                            "severity": "low",
                            "url": url,
                            "evidence": "Cookies set without SameSite attribute",
                        })

                    referrer = resp.headers.get("Referrer-Policy", "")
                    if not referrer:
                        results.append({
                            "finding_type": "CSRF (No Referrer Policy)",
                            "severity": "info",
                            "url": url,
                            "evidence": "No Referrer-Policy header",
                        })
        except Exception:
            pass
    return results
