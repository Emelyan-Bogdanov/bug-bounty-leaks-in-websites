from typing import Optional
import aiohttp
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse

REDIRECT_PAYLOADS = [
    "//evil.com",
    "https://evil.com",
    "//google.com",
    "/\\evil.com",
    "https:evil.com",
    "//evil.com@google.com",
]


async def run(target: str, scan_id: Optional[int] = None) -> list[dict]:
    results = []
    url = f"https://{target}" if not target.startswith("http") else target
    parsed = urlparse(url)
    params = parse_qs(parsed.query)
    if not params:
        params = {"url": [""], "next": [""], "redirect": [""], "return": [""]}

    async with aiohttp.ClientSession() as session:
        for param, values in params.items():
            for payload in REDIRECT_PAYLOADS:
                try:
                    test_params = params.copy()
                    test_params[param] = [payload]
                    test_qs = urlencode(test_params, doseq=True)
                    test_url = urlunparse(parsed._replace(query=test_qs))
                    async with session.get(test_url, timeout=aiohttp.ClientTimeout(total=10), allow_redirects=False) as resp:
                        location = resp.headers.get("Location", "")
                        if location and ("evil.com" in location or "google.com" in location):
                            results.append({
                                "finding_type": "Open Redirect",
                                "severity": "medium",
                                "url": test_url,
                                "parameter": param,
                                "payload": payload,
                                "evidence": f"Redirects to: {location}",
                            })
                            break
                except Exception:
                    pass
    return results
