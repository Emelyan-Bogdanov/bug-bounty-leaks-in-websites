from typing import Optional
import aiohttp
import json


TECH_CVE_DB = {
    "nginx": ["CVE-2023-44487", "CVE-2021-23017"],
    "apache": ["CVE-2023-25690", "CVE-2021-44790"],
    "wordpress": ["CVE-2023-5360", "CVE-2022-21661"],
    "django": ["CVE-2024-24680", "CVE-2023-31047"],
    "flask": ["CVE-2023-30861"],
    "express": [],
    "php": ["CVE-2024-4577", "CVE-2023-3824"],
    "iis": ["CVE-2023-38156", "CVE-2022-21907"],
    "openssl": ["CVE-2023-38157", "CVE-2022-3786"],
}


async def run(target: str, scan_id: Optional[int] = None) -> list[dict]:
    results = []

    for tech, cves in TECH_CVE_DB.items():
        for cve_id in cves:
            try:
                async with aiohttp.ClientSession() as session:
                    url = f"https://services.nvd.nist.gov/rest/json/cves/2.0?cveId={cve_id}"
                    async with session.get(url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                        if resp.status == 200:
                            data = await resp.json()
                            vuln = data.get("vulnerabilities", [{}])[0].get("cve", {})
                            desc = ""
                            for d in vuln.get("descriptions", []):
                                if d.get("lang") == "en":
                                    desc = d["value"]
                                    break
                            score = ""
                            metrics = vuln.get("metrics", {})
                            if "cvssMetricV31" in metrics:
                                score = str(metrics["cvssMetricV31"][0].get("cvssData", {}).get("baseScore", ""))
                            elif "cvssMetricV30" in metrics:
                                score = str(metrics["cvssMetricV30"][0].get("cvssData", {}).get("baseScore", ""))
                            evidence = f"{cve_id} (CVSS: {score}) — {desc[:200]}"
                            results.append({
                                "finding_type": f"CVE — {tech}",
                                "severity": "high",
                                "url": target,
                                "evidence": evidence,
                            })
            except Exception:
                pass

    return results
