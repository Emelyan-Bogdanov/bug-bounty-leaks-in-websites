from typing import Optional
import aiohttp


async def run(target: str, scan_id: Optional[int] = None) -> list[dict]:
    results = []
    url = f"https://{target}" if not target.startswith("http") else target
    malicious_origins = [
        "https://evil.com",
        "https://malicious.io",
        "null",
    ]

    async with aiohttp.ClientSession() as session:
        for origin in malicious_origins:
            try:
                async with session.get(
                    url,
                    headers={"Origin": origin},
                    timeout=aiohttp.ClientTimeout(total=10),
                ) as resp:
                    acao = resp.headers.get("Access-Control-Allow-Origin", "")
                    acc = resp.headers.get("Access-Control-Allow-Credentials", "")
                    if acao == "*":
                        results.append({
                            "finding_type": "CORS Wildcard",
                            "severity": "high",
                            "url": url,
                            "evidence": "Access-Control-Allow-Origin: *",
                        })
                    elif acao == origin and acc.lower() == "true":
                        results.append({
                            "finding_type": "CORS Credentialed",
                            "severity": "high",
                            "url": url,
                            "evidence": f"ACAO: {origin} with credentials allowed",
                        })
                    elif acao == origin:
                        results.append({
                            "finding_type": "CORS Reflect",
                            "severity": "medium",
                            "url": url,
                            "evidence": f"Origin reflection: {origin}",
                        })
            except Exception:
                pass
    return results
