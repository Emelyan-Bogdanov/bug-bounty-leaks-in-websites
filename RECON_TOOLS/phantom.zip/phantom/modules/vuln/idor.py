from typing import Optional
import aiohttp
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse


async def run(target: str, scan_id: Optional[int] = None) -> list[dict]:
    results = []
    url = f"https://{target}" if not target.startswith("http") else target
    parsed = urlparse(url)
    params = parse_qs(parsed.query)

    id_params = [k for k in params if k.lower() in ("id", "uid", "user_id", "account", "order", "customer", "file_id")]

    import re
    ids_found = set()
    for param in id_params:
        for val in params.get(param, []):
            nums = re.findall(r"\d+", val)
            ids_found.update(int(n) for n in nums)

    if not ids_found and not id_params:
        test_params_by_name = {"id": ["1"], "uid": ["1"], "user_id": ["1"]}
    else:
        test_params_by_name = {}

    async with aiohttp.ClientSession() as session:
        test_set = {}
        if ids_found:
            for orig_id in list(ids_found)[:3]:
                for delta in (1, -1, 10, 100):
                    test_set[orig_id + delta] = str(orig_id + delta)

        for param_name, vals in test_params_by_name.items():
            for val in vals:
                try:
                    test_params = params.copy()
                    test_params[param_name] = [val]
                    test_qs = urlencode(test_params, doseq=True)
                    test_url = urlunparse(parsed._replace(query=test_qs))
                    async with session.get(test_url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                        if resp.status == 200:
                            text = await resp.text()
                            if "dashboard" in text.lower() or "welcome" in text.lower() or "profile" in text.lower():
                                results.append({
                                    "finding_type": "IDOR (Potential)",
                                    "severity": "high",
                                    "url": test_url,
                                    "parameter": param_name,
                                    "payload": val,
                                    "evidence": f"Accessed {param_name}={val} — HTTP {resp.status}",
                                })
                except Exception:
                    pass

        for new_id, orig in test_set.items():
            for param in id_params:
                try:
                    test_params = params.copy()
                    test_params[param] = [str(new_id)]
                    test_qs = urlencode(test_params, doseq=True)
                    test_url = urlunparse(parsed._replace(query=test_qs))
                    async with session.get(test_url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                        if resp.status == 200:
                            text = await resp.text()
                            if "not found" not in text.lower() and "error" not in text.lower():
                                results.append({
                                    "finding_type": "IDOR (Sequential)",
                                    "severity": "high",
                                    "url": test_url,
                                    "parameter": param,
                                    "payload": str(new_id),
                                    "evidence": f"Sequential ID {new_id} accessible",
                                })
                except Exception:
                    pass
    return results
