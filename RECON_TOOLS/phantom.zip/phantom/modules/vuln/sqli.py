from typing import Optional
import aiohttp
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse

ERROR_PATTERNS = [
    r"SQL syntax.*MySQL",
    r"Warning.*mysql_",
    r"Unclosed quotation mark",
    r"Microsoft OLE DB.*SQL Server",
    r"SQLite/JDBCDriver",
    r"SQL error.*PostgreSQL",
    r"driver.*SQL Server",
    r"ORA-[0-9]{5}",
    r"PostgreSQL.*ERROR",
]

TEST_PAYLOADS = [
    "'",
    "\"",
    "1' OR '1'='1",
    "1\" OR \"1\"=\"1",
    "' OR 1=1 --",
    "\" OR 1=1 --",
    "' UNION SELECT NULL --",
    "' AND SLEEP(5) --",
    "'; WAITFOR DELAY '0:0:5' --",
]


async def run(target: str, scan_id: Optional[int] = None) -> list[dict]:
    results = []
    url = f"https://{target}" if not target.startswith("http") else target
    parsed = urlparse(url)
    params = parse_qs(parsed.query)
    if not params:
        params = {"q": [""], "id": [""], "page": [""]}

    async with aiohttp.ClientSession() as session:
        for param, values in params.items():
            for payload in TEST_PAYLOADS:
                try:
                    test_params = params.copy()
                    test_params[param] = [payload.replace("{param}", values[0]) if values else payload]
                    test_qs = urlencode(test_params, doseq=True)
                    test_url = urlunparse(parsed._replace(query=test_qs))
                    async with session.get(test_url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                        text = await resp.text()
                        for pattern in ERROR_PATTERNS:
                            import re
                            if re.search(pattern, text, re.IGNORECASE):
                                results.append({
                                    "finding_type": "SQL Injection",
                                    "severity": "critical",
                                    "url": test_url,
                                    "parameter": param,
                                    "payload": payload,
                                    "evidence": f"Error pattern matched: {pattern}",
                                })
                                break
                except Exception:
                    pass
    return results
