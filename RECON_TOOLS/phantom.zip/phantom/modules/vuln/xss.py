from typing import Optional
import aiohttp
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse

XSS_PAYLOADS = [
    "<script>alert(1)</script>",
    "<img src=x onerror=alert(1)>",
    "\"><script>alert(1)</script>",
    "javascript:alert(1)",
    "<svg onload=alert(1)>",
    "'-alert(1)-'",
    "\";alert(1);//",
]


async def run(target: str, scan_id: Optional[int] = None) -> list[dict]:
    results = []
    url = f"https://{target}" if not target.startswith("http") else target
    parsed = urlparse(url)
    params = parse_qs(parsed.query)
    if not params:
        params = {"q": [""], "search": [""], "name": [""]}

    async with aiohttp.ClientSession() as session:
        for param, values in params.items():
            for payload in XSS_PAYLOADS:
                try:
                    test_params = params.copy()
                    test_params[param] = [payload]
                    test_qs = urlencode(test_params, doseq=True)
                    test_url = urlunparse(parsed._replace(query=test_qs))
                    async with session.get(test_url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                        text = await resp.text()
                        if payload in text:
                            results.append({
                                "finding_type": "XSS (Reflected)",
                                "severity": "high",
                                "url": test_url,
                                "parameter": param,
                                "payload": payload,
                                "evidence": f"Payload reflected in response",
                            })
                            break
                except Exception:
                    pass
    return results
