from typing import Optional
import aiohttp
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse

SSTI_PAYLOADS = [
    "{{7*7}}",
    "${7*7}",
    "#{7*7}",
    "${{7*7}}",
    "{{config}}",
    "${7*'7'}",
    "{{7*'7'}}",
    "*{7*7}",
]


async def run(target: str, scan_id: Optional[int] = None) -> list[dict]:
    results = []
    url = f"https://{target}" if not target.startswith("http") else target
    parsed = urlparse(url)
    params = parse_qs(parsed.query)
    if not params:
        params = {"name": [""], "user": [""], "page": [""]}

    async with aiohttp.ClientSession() as session:
        for param, values in params.items():
            for payload in SSTI_PAYLOADS:
                try:
                    test_params = params.copy()
                    test_params[param] = [payload]
                    test_qs = urlencode(test_params, doseq=True)
                    test_url = urlunparse(parsed._replace(query=test_qs))
                    async with session.get(test_url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                        text = await resp.text()
                        if "49" in text and "{{7*7}}" in payload:
                            results.append({
                                "finding_type": "SSTI",
                                "severity": "high",
                                "url": test_url,
                                "parameter": param,
                                "payload": payload,
                                "evidence": f"Expression evaluated: 7*7=49",
                            })
                            break
                        if "config" in text and payload == "{{config}}":
                            results.append({
                                "finding_type": "SSTI (Config Leak)",
                                "severity": "high",
                                "url": test_url,
                                "parameter": param,
                                "payload": payload,
                                "evidence": "Flask config object exposed",
                            })
                            break
                except Exception:
                    pass
    return results
