from typing import Optional
import aiohttp
import re
import socket


async def run(target: str, scan_id: Optional[int] = None) -> list[dict]:
    results = []
    host = target
    if ":" in host:
        host = host.split(":")[0]
    try:
        ip = socket.gethostbyname(host)
        results.append({"finding_type": "Resolved IP", "severity": "info", "url": target, "evidence": ip})
        url = f"https://whois.arin.net/rest/ip/{ip}.json"
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    net = data.get("net", {})
                    asn = net.get("name", "")
                    cidr = net.get("cidr", "")
                    handle = net.get("handle", "")
                    if asn:
                        results.append({"finding_type": "ASN", "severity": "info", "url": target, "evidence": f"ASN: {asn}"})
                    if cidr:
                        results.append({"finding_type": "CIDR Range", "severity": "info", "url": target, "evidence": cidr})
                    if handle:
                        results.append({"finding_type": "Net Handle", "severity": "info", "url": target, "evidence": handle})
    except Exception as e:
        results.append({"finding_type": "ASN Lookup Error", "severity": "info", "url": target, "evidence": str(e)})
    return results
