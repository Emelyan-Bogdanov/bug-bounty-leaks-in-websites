from typing import Optional
from pathlib import Path


async def run(target: str, scan_id: Optional[int] = None) -> list[dict]:
    results = []
    url = f"https://{target}" if not target.startswith("http") else target
    output_dir = Path("data/screenshots")
    output_dir.mkdir(parents=True, exist_ok=True)
    try:
        from playwright.async_api import async_playwright
        async with async_playwright() as p:
            browser = await p.chromium.launch()
            page = await browser.new_page()
            await page.goto(url, wait_until="domcontentloaded", timeout=30000)
            filename = f"{target.replace('.', '_').replace(':', '_')}.png"
            path = str(output_dir / filename)
            await page.screenshot(path=path, full_page=True)
            await browser.close()
            results.append({
                "finding_type": "Screenshot",
                "severity": "info",
                "url": url,
                "evidence": f"Screenshot saved to {path}",
            })
    except ImportError:
        results.append({
            "finding_type": "Screenshot Error",
            "severity": "info",
            "url": url,
            "evidence": "Playwright not installed. Run: playwright install chromium",
        })
    except Exception as e:
        results.append({
            "finding_type": "Screenshot Error",
            "severity": "info",
            "url": url,
            "evidence": str(e),
        })
    return results
