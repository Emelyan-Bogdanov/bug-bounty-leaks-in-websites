from typing import Optional
import whois


async def run(target: str, scan_id: Optional[int] = None) -> list[dict]:
    results = []
    try:
        w = whois.whois(target)
        fields = {
            "registrar": w.registrar,
            "creation_date": str(w.creation_date) if w.creation_date else None,
            "expiration_date": str(w.expiration_date) if w.expiration_date else None,
            "name_servers": ", ".join(w.name_servers) if w.name_servers else None,
            "registrant": getattr(w, "name", None),
            "org": getattr(w, "org", None),
            "country": getattr(w, "country", None),
        }
        for key, val in fields.items():
            if val:
                results.append({
                    "finding_type": f"WHOIS {key}",
                    "severity": "info",
                    "url": target,
                    "evidence": str(val),
                })
    except Exception as e:
        results.append({
            "finding_type": "WHOIS Error",
            "severity": "info",
            "url": target,
            "evidence": str(e),
        })
    return results
