import asyncio
from typing import Optional
import dns.asyncresolver
import dns.resolver
import dns.zone
import dns.query
import dns.name

RECORD_TYPES = ["A", "AAAA", "MX", "NS", "TXT", "CNAME", "SOA"]


async def run(target: str, scan_id: Optional[int] = None) -> list[dict]:
    results = []
    resolver = dns.asyncresolver.Resolver()
    resolver.timeout = 5
    resolver.lifetime = 10

    for rtype in RECORD_TYPES:
        try:
            answers = await resolver.resolve(target, rtype)
            for rdata in answers:
                results.append({
                    "finding_type": f"DNS {rtype}",
                    "severity": "info",
                    "url": target,
                    "evidence": str(rdata),
                })
        except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN, dns.exception.Timeout):
            pass
        except Exception as e:
            results.append({
                "finding_type": f"DNS {rtype} Error",
                "severity": "info",
                "url": target,
                "evidence": str(e),
            })

    try:
        ns_answers = await resolver.resolve(target, "NS")
        for ns in ns_answers:
            try:
                ns_name = str(ns).rstrip(".")
                zone = dns.zone.from_xfr(dns.query.xfr(str(ns_name), target, timeout=5))
                for name, node in zone.nodes.items():
                    results.append({
                        "finding_type": "DNS Zone Transfer",
                        "severity": "high",
                        "url": target,
                        "evidence": f"Zone transfer succeeded from {ns_name}: {name}",
                    })
            except Exception:
                pass
    except Exception:
        pass

    return results
