from typing import Optional
import aiohttp
import re

TECH_PATTERNS = {
    "nginx": [r"nginx/([\d.]+)", r"Server: nginx"],
    "apache": [r"Apache[/\s]([\d.]+)", r"Server: Apache"],
    "cloudflare": [r"cloudflare", r"CF-RAY"],
    "wordpress": [r"/wp-content/", r"/wp-admin/", r"WordPress"],
    "django": [r"csrftoken", r"Django"],
    "flask": [r"flask", r"FLASK"],
    "express": [r"Express", r"X-Powered-By: Express"],
    "react": [r"react", r"React", r"__NEXT_DATA__"],
    "vue": [r"vue", r"Vue"],
    "angular": [r"angular", r"Angular"],
    "php": [r"X-Powered-By: PHP", r"\.php"],
    "ruby": [r"Ruby on Rails", r"rails"],
    "node.js": [r"node.js", r"Node"],
    "iis": [r"IIS", r"X-Powered-By: ASP\.NET"],
    "shibboleth": [r"Shibboleth"],
}


async def run(target: str, scan_id: Optional[int] = None) -> list[dict]:
    results = []
    url = f"https://{target}" if not target.startswith("http") else target
    async with aiohttp.ClientSession() as session:
        try:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                text = await resp.text()
                headers = dict(resp.headers)
                combined = text + str(headers)
                for tech, patterns in TECH_PATTERNS.items():
                    for pat in patterns:
                        if re.search(pat, combined, re.IGNORECASE):
                            results.append({
                                "finding_type": "Technology Detected",
                                "severity": "info",
                                "url": url,
                                "evidence": f"{tech} (matched: {pat})",
                            })
                            break
        except Exception:
            pass
    return results
