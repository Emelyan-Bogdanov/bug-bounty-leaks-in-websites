from typing import Optional
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
import aiohttp
import asyncio

from core.config import config


async def _crawl(url: str, depth: int, visited: set, results: list, max_pages: int = 50):
    if depth > config.max_depth or len(visited) >= max_pages or url in visited:
        return
    visited.add(url)
    async with aiohttp.ClientSession() as session:
        try:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                if "text/html" not in resp.headers.get("Content-Type", ""):
                    return
                text = await resp.text()
                soup = BeautifulSoup(text, "lxml")
                for tag in soup.find_all(["a", "link", "script", "img", "form"]):
                    href = tag.get("href") or tag.get("src") or tag.get("action")
                    if href:
                        full = urljoin(url, href)
                        parsed = urlparse(full)
                        if parsed.netloc == urlparse(url).netloc and full not in visited:
                            results.append({
                                "finding_type": "Crawled URL",
                                "severity": "info",
                                "url": full,
                                "evidence": f"Found in {url}",
                            })
                            await _crawl(full, depth + 1, visited, results, max_pages)
        except Exception:
            pass


async def run(target: str, scan_id: Optional[int] = None) -> list[dict]:
    results = []
    url = f"https://{target}" if not target.startswith("http") else target
    visited = set()
    await _crawl(url, 0, visited, results)
    return results
