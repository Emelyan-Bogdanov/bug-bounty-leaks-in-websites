from typing import Optional
import aiohttp


async def run(target: str, scan_id: Optional[int] = None) -> list[dict]:
    results = []
    url = f"https://crt.sh/?q=%25.{target}&output=json"
    async with aiohttp.ClientSession() as session:
        try:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=15)) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    seen = set()
                    for entry in data:
                        name = entry.get("name_value", "")
                        for sub in name.split("\n"):
                            sub = sub.strip()
                            if sub.endswith(target) and sub not in seen:
                                seen.add(sub)
                                results.append({
                                    "finding_type": "Certificate Transparency",
                                    "severity": "info",
                                    "url": sub,
                                    "evidence": f"Found in crt.sh | issuer: {entry.get('issuer_name', 'N/A')}",
                                })
        except Exception as e:
            results.append({
                "finding_type": "CT Log Error",
                "severity": "info",
                "url": target,
                "evidence": str(e),
            })
    return results
