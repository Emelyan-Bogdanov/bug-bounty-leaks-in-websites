import asyncio
import socket
from typing import Optional
from pathlib import Path
import aiohttp

from core.config import config
from core.logger import logger


async def _load_wordlist() -> list[str]:
    path = config.wordlists.get("subdomains")
    if path and Path(path).exists():
        with open(path) as f:
            return [line.strip() for line in f if line.strip()]
    return ["www", "mail", "api", "admin", "dev", "blog", "test"]


async def _bruteforce(domain: str) -> list[dict]:
    results = []
    wordlist = await _load_wordlist()
    for word in wordlist:
        sub = f"{word}.{domain}"
        try:
            ip = socket.getaddrinfo(sub, 80, proto=socket.IPPROTO_TCP)[0][4][0]
            results.append({
                "finding_type": "Subdomain",
                "severity": "info",
                "url": sub,
                "evidence": ip,
            })
        except (socket.gaierror, IndexError):
            pass
    return results


async def _passive(domain: str) -> list[dict]:
    results = []
    sources = [
        f"https://crt.sh/?q=%25.{domain}&output=json",
        f"https://dnsdumpster.com/",
    ]
    async with aiohttp.ClientSession() as session:
        try:
            async with session.get(sources[0], timeout=aiohttp.ClientTimeout(total=10)) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    seen = set()
                    for entry in data:
                        name = entry.get("name_value", "")
                        for sub in name.split("\n"):
                            sub = sub.strip()
                            if sub.endswith(domain) and sub not in seen:
                                seen.add(sub)
                                results.append({
                                    "finding_type": "Subdomain (passive)",
                                    "severity": "info",
                                    "url": sub,
                                    "evidence": "crt.sh",
                                })
        except Exception:
            pass
    return results


async def run(target: str, scan_id: Optional[int] = None, passive_only: bool = False) -> list[dict]:
    results = []
    if not passive_only:
        results.extend(await _bruteforce(target))
    results.extend(await _passive(target))
    return results
