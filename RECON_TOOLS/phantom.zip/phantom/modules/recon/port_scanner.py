import asyncio
from typing import Optional
import socket

TOP_PORTS = [
    21, 22, 23, 25, 53, 80, 110, 111, 135, 139, 143, 443, 445, 993, 995,
    1433, 1521, 2049, 3306, 3389, 5432, 5900, 5985, 5986, 6379, 8080, 8443,
    9000, 9090, 27017,
]


async def _scan_port(host: str, port: int, timeout: float = 2.0) -> dict | None:
    try:
        _, writer = await asyncio.wait_for(
            asyncio.open_connection(host, port),
            timeout=timeout,
        )
        writer.close()
        await writer.wait_closed()
        return {"finding_type": "Open Port", "severity": "info", "url": f"{host}:{port}", "evidence": f"TCP port {port} open"}
    except (TimeoutError, ConnectionRefusedError, OSError):
        return None


async def run(target: str, scan_id: Optional[int] = None, ports: list[int] | None = None) -> list[dict]:
    host = target
    if ":" in host:
        host = host.split(":")[0]
    target_ports = ports or TOP_PORTS

    tasks = [_scan_port(host, p) for p in target_ports]
    results = await asyncio.gather(*tasks)
    return [r for r in results if r is not None]
