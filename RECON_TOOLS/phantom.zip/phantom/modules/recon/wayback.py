from typing import Optional
import aiohttp


async def run(target: str, scan_id: Optional[int] = None) -> list[dict]:
    results = []
    url = f"https://web.archive.org/cdx/search/cdx?url={target}/*&output=json&fl=original,timestamp,statuscode&limit=1000"
    async with aiohttp.ClientSession() as session:
        try:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=30)) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    seen = set()
                    for entry in data[1:]:
                        original = entry[0]
                        ts = entry[1]
                        code = entry[2] if len(entry) > 2 else "-"
                        if original not in seen:
                            seen.add(original)
                            results.append({
                                "finding_type": "Wayback URL",
                                "severity": "info",
                                "url": original,
                                "evidence": f"Archived: {ts} (HTTP {code})",
                            })
        except Exception as e:
            results.append({
                "finding_type": "Wayback Error",
                "severity": "info",
                "url": target,
                "evidence": str(e),
            })
    return results
