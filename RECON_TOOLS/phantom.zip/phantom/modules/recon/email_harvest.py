from typing import Optional
import re
import aiohttp
from bs4 import BeautifulSoup

EMAIL_RE = re.compile(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}")


async def run(target: str, scan_id: Optional[int] = None) -> list[dict]:
    results = []
    url = f"https://{target}" if not target.startswith("http") else target
    async with aiohttp.ClientSession() as session:
        try:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                text = await resp.text()
                soup = BeautifulSoup(text, "lxml")
                emails = set(EMAIL_RE.findall(soup.get_text()))
                for email in sorted(emails):
                    if not email.endswith(".png") and not email.endswith(".jpg"):
                        results.append({
                            "finding_type": "Email Address",
                            "severity": "info",
                            "url": url,
                            "evidence": email,
                        })
        except Exception as e:
            results.append({
                "finding_type": "Email Harvest Error",
                "severity": "info",
                "url": url,
                "evidence": str(e),
            })

    if config.api_keys.get("hunter_io"):
        try:
            hunter_url = f"https://api.hunter.io/v2/domain-search?domain={target}&api_key={config.api_keys['hunter_io']}"
            async with session.get(hunter_url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    for email_data in data.get("data", {}).get("emails", []):
                        results.append({
                            "finding_type": "Email (Hunter.io)",
                            "severity": "info",
                            "url": target,
                            "evidence": f"{email_data['value']} ({email_data.get('type', 'unknown')})",
                        })
        except Exception:
            pass

    return results
