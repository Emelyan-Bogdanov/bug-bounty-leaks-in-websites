from typing import Optional
import aiohttp
import urllib.parse

DORKS = [
    {"name": "Login Pages", "dork": "site:{target} inurl:login"},
    {"name": "Admin Panels", "dork": "site:{target} inurl:admin"},
    {"name": "Config Files", "dork": "site:{target} ext:cfg|conf|config|ini"},
    {"name": "Database Backups", "dork": "site:{target} ext:sql|bak|dump"},
    {"name": "Exposed Logs", "dork": "site:{target} ext:log"},
    {"name": "Error Messages", "dork": "site:{target} intext:\"error\" intext:\"warning\""},
    {"name": "Directory Listing", "dork": "site:{target} intitle:\"index of\""},
    {"name": "Environment Files", "dork": "site:{target} ext:env"},
    {"name": "API Endpoints", "dork": "site:{target} inurl:api"},
    {"name": "PHP Info", "dork": "site:{target} ext:php intitle:\"phpinfo\""},
]


async def run(target: str, scan_id: Optional[int] = None) -> list[dict]:
    results = []
    for dork_def in DORKS:
        dork_query = dork_def["dork"].format(target=target)
        encoded = urllib.parse.quote(dork_query)
        url = f"https://www.google.com/search?q={encoded}"
        results.append({
            "finding_type": "Google Dork",
            "severity": "info",
            "url": url,
            "evidence": f"{dork_def['name']}: {dork_query}",
        })
    return results
