from typing import Optional
import shodan

from core.config import config


async def run(target: str, scan_id: Optional[int] = None) -> list[dict]:
    results = []
    api_key = config.api_keys.get("shodan")
    if not api_key:
        results.append({
            "finding_type": "Shodan Error",
            "severity": "info",
            "url": target,
            "evidence": "No Shodan API key configured",
        })
        return results

    try:
        api = shodan.Shodan(api_key)
        host = await _resolve_host(target)
        if host:
            info = api.host(host)
            results.append({
                "finding_type": "Shodan Info",
                "severity": "info",
                "url": target,
                "evidence": f"OS: {info.get('os', 'Unknown')}, Ports: {info.get('ports', [])}",
            })
            for service in info.get("data", []):
                if service.get("vulns"):
                    results.append({
                        "finding_type": "Shodan CVE",
                        "severity": "high",
                        "url": f"{target}:{service.get('port')}",
                        "evidence": f"Vulns: {', '.join(service['vulns'])}",
                    })
    except shodan.exception.APIError as e:
        results.append({
            "finding_type": "Shodan API Error",
            "severity": "info",
            "url": target,
            "evidence": str(e),
        })
    except Exception:
        pass
    return results


async def _resolve_host(target: str) -> str | None:
    import socket
    try:
        return socket.gethostbyname(target)
    except Exception:
        return None
