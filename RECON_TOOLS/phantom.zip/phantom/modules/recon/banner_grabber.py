import asyncio
from typing import Optional


async def _grab_banner(host: str, port: int, timeout: float = 3.0) -> dict | None:
    try:
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(host, port),
            timeout=timeout,
        )
        if port in (80, 8080, 443, 8443):
            writer.write(f"HEAD / HTTP/1.0\r\nHost: {host}\r\n\r\n".encode())
        elif port == 21:
            pass
        elif port == 22:
            pass
        await writer.drain()
        banner = await asyncio.wait_for(reader.read(1024), timeout=timeout)
        writer.close()
        await writer.wait_closed()
        decoded = banner.decode("utf-8", errors="replace").strip()
        if decoded:
            return {"finding_type": "Banner", "severity": "info", "url": f"{host}:{port}", "evidence": decoded[:500]}
    except Exception:
        pass
    return None


async def run(target: str, scan_id: Optional[int] = None) -> list[dict]:
    host = target.split(":")[0]
    common_ports = [21, 22, 25, 80, 443, 8080, 8443]
    tasks = [_grab_banner(host, p) for p in common_ports]
    results = await asyncio.gather(*tasks)
    return [r for r in results if r is not None]
