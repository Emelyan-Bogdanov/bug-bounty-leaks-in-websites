from rich.console import Console
from rich.table import Table
from rich.panel import Panel

from core.config import config

console = Console()


def result_table(results: list, title: str = "Results") -> Panel:
    table = Table(
        show_header=True,
        header_style="bold cyan",
        title_justify="left",
        box=None,
    )
    table.add_column("Severity", style="bold", width=10)
    table.add_column("Type", width=30)
    table.add_column("URL", width=50, no_wrap=True)
    table.add_column("Parameter", width=15)
    table.add_column("Evidence", width=40, overflow="fold")

    severity_colors = {
        "critical": "red",
        "high": "yellow",
        "medium": "orange1",
        "low": "green",
        "info": "blue",
    }

    for r in results[:config.max_table_rows]:
        sev = r.severity if isinstance(r, dict) else getattr(r, "severity", "info")
        color = severity_colors.get(sev, "white")
        table.add_row(
            f"[{color}]{sev.upper()}[/{color}]",
            r["finding_type"] if isinstance(r, dict) else r.finding_type or "",
            r["url"] if isinstance(r, dict) else r.url or "",
            r.get("parameter", "") if isinstance(r, dict) else getattr(r, "parameter", "") or "",
            r.get("evidence", "") if isinstance(r, dict) else r.evidence or "",
        )

    if len(results) > config.max_table_rows:
        table.add_row("...", f"[dim]{len(results) - config.max_table_rows} more[/dim]", "", "", "")

    return Panel(table, title=f"[bold]{title}[/bold]", border_style="blue")


def target_table(targets: list) -> Table:
    table = Table(show_header=True, header_style="bold cyan")
    table.add_column("ID", style="dim")
    table.add_column("Name")
    table.add_column("Domain/IP")
    table.add_column("Type")
    table.add_column("Status")
    table.add_column("Findings")
    table.add_column("Last Scan")
    return table


def severity_bar(counts: dict) -> str:
    parts = []
    for sev, color in [("critical", "red"), ("high", "yellow"), ("medium", "orange1"), ("low", "green"), ("info", "blue")]:
        c = counts.get(sev, 0)
        if c:
            parts.append(f"[{color}]{sev}: {c}[/{color}]")
    return " | ".join(parts) if parts else "[dim]No findings[/dim]"
