from rich.progress import (
    Progress,
    SpinnerColumn,
    TextColumn,
    BarColumn,
    TaskProgressColumn,
    TimeRemainingColumn,
    TimeElapsedColumn,
)
from rich.console import Console
from rich.table import Column

from core.config import config

console = Console()


def scan_progress() -> Progress:
    return Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        TimeRemainingColumn(),
        TimeElapsedColumn(),
        console=console,
        refresh_per_second=config.progress_refresh_rate,
        transient=True,
    )


def spinner_progress(message: str = "Working...") -> Progress:
    return Progress(
        SpinnerColumn(),
        TextColumn(f"[bold cyan]{message}[/bold cyan]"),
        console=console,
        transient=True,
    )
