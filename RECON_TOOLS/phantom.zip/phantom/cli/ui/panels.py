from rich.console import Console
from rich.panel import Panel
from rich import box

console = Console()


def banner(title: str, subtitle: str = ""):
    from core.config import config
    panel = Panel.fit(
        f"[bold cyan]{config.name}[/bold cyan] [white]v{config.version}[/white]\n"
        f"[dim]{title}[/dim]" + (f"\n[white]{subtitle}[/white]" if subtitle else ""),
        border_style="cyan",
        box=box.HEAVY,
        padding=(1, 4),
    )
    console.print(panel)


def info_panel(title: str, content: str, style: str = "blue"):
    console.print(Panel(content, title=f"[bold]{title}[/bold]", border_style=style))


def error_panel(message: str):
    console.print(Panel(f"[red]{message}[/red]", title="[bold red]Error[/bold red]", border_style="red"))


def success_panel(message: str):
    console.print(Panel(f"[green]{message}[/green]", title="[bold green]Success[/bold green]", border_style="green"))
