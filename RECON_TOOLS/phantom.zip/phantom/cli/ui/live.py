from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich.console import Console, Group
from rich.text import Text
from datetime import datetime
from collections import deque

from core.config import config

console = Console()


class LiveDisplay:
    def __init__(self, target: str, modules: list[str]):
        self.target = target
        self.modules = modules
        self.module_status = {m: "pending" for m in modules}
        self.log_lines = deque(maxlen=20)
        self.result_count = 0
        self.critical_count = 0
        self.start_time = datetime.now()

    def update_module(self, module: str, status: str):
        self.module_status[module] = status

    def add_log(self, message: str):
        self.log_lines.append(f"[dim]{datetime.now().strftime('%H:%M:%S')}[/dim] {message}")

    def increment_results(self, severity: str = "info"):
        self.result_count += 1
        if severity in ("critical", "high"):
            self.critical_count += 1

    def render(self) -> Panel:
        status_colors = {"running": "cyan", "completed": "green", "failed": "red", "pending": "dim white"}
        module_lines = []
        for m in self.modules:
            color = status_colors.get(self.module_status.get(m, "pending"), "white")
            module_lines.append(f"  [{color}]● {m}[/{color}]")

        summary = Table.grid(padding=(0, 2))
        summary.add_column(style="bold cyan")
        summary.add_column()
        summary.add_row("Target", self.target)
        summary.add_row("Modules", str(len(self.modules)))
        summary.add_row("Results", str(self.result_count))
        summary.add_row("Critical/High", f"[bold red]{self.critical_count}[/bold red]")
        summary.add_row("Elapsed", str(datetime.now() - self.start_time).split(".")[0])

        content = Group(
            summary,
            Text("\nModule Status", style="bold"),
            Text("\n".join(module_lines)),
            Text("\nLive Log", style="bold"),
            Text("\n".join(self.log_lines)),
        )

        return Panel(
            content,
            title=f"[bold cyan]PHANTOM — Live Scan[/bold cyan]",
            border_style="cyan",
        )
