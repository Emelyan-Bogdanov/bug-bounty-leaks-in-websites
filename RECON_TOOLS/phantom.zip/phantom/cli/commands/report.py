import typer
from rich.console import Console
from rich.panel import Panel
import asyncio

from core.db import db, Target, Report
from cli.ui.panels import banner
from datetime import datetime

app = typer.Typer(help="Generate reports")
console = Console()


@app.callback()
def main():
    pass


@app.command()
def generate(
    target: str = typer.Argument(..., help="Target name, domain, or ID"),
    format: str = typer.Option("html", "--format", "-f", help="Report format: pdf, html, csv, json, md"),
    output: str = typer.Option("", "--output", "-o", help="Output file path"),
):
    banner("PHANTOM Report Generator")

    db_target = Target.query.filter(
        (Target.name == target) | (Target.domain == target) | (Target.id == int(target) if target.isdigit() else -1)
    ).first()

    if not db_target:
        console.print("[red]Target not found[/red]")
        raise typer.Exit(1)

    format_map = {
        "html": "modules.reporting.html_report",
        "pdf": "modules.reporting.pdf_report",
        "csv": "modules.reporting.csv_export",
        "json": "modules.reporting.json_export",
    }

    mod_path = format_map.get(format)
    if not mod_path:
        console.print(f"[red]Unknown format: {format}[/red]")
        raise typer.Exit(1)

    import importlib
    mod = importlib.import_module(mod_path)
    results = asyncio.run(mod.run(db_target.id))

    for r in results:
        console.print(Panel(r.get("evidence", ""), title=f"[bold green]{r['finding_type']}[/bold green]"))

    report = Report(
        target_id=db_target.id,
        format=format,
        file_path=results[0].get("url", ""),
        generated_by="cli",
    )
    db.session.add(report)
    db.session.commit()
