import typer
from rich.console import Console
from rich.panel import Panel
import asyncio

from core.db import db, Target, Scan
from core.engine import engine
from cli.ui.panels import banner
from cli.ui.tables import result_table

app = typer.Typer(help="Run recon modules on a target")
console = Console()


@app.callback()
def main():
    pass


@app.command()
def run(
    target: str = typer.Argument(..., help="Target domain or IP"),
    module: str = typer.Option("all", "--module", "-m", help="Specific recon module"),
    passive: bool = typer.Option(False, "--passive", help="Passive only (no direct scanning)"),
):
    banner("PHANTOM Reconnaissance")
    from core.utils import normalize_target
    val, ttype = normalize_target(target)

    db_target = Target(name=val, domain=val, type=ttype, status="new")
    db.session.add(db_target)
    db.session.commit()

    if module == "all":
        mod_list = [m for m in engine.list_modules("recon")]
    else:
        mod_list = [f"recon.{module}"] if engine.get_module(f"recon.{module}") else []

    if passive:
        passive_mods = ["recon.subdomain", "recon.cert_transparency", "recon.wayback", "recon.email_harvest"]
        mod_list = [m for m in mod_list if m in passive_mods]

    scan = Scan(target_id=db_target.id, modules=",".join(mod_list), status="pending", triggered_by="cli")
    db.session.add(scan)
    db.session.commit()

    asyncio.run(engine.run_scan(scan.id, mod_list))
    results = db_target.scans.order_by(Scan.id.desc()).first().results.all()
    console.print(result_table([r for r in results], title="Recon Results"))
