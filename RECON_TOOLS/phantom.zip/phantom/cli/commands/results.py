import typer
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

from core.db import db, Target, Scan, ScanResult
from cli.ui.panels import banner
from cli.ui.tables import result_table

app = typer.Typer(help="View scan results")
console = Console()


@app.callback()
def main():
    pass


@app.command()
def show(
    target: str = typer.Option("", "--target", "-t", help="Target name, domain, or ID"),
    format: str = typer.Option("table", "--format", "-f", help="Output format: table, detailed"),
    scan_id: int = typer.Option(0, "--scan", "-s", help="Specific scan ID"),
    severity: str = typer.Option("", "--severity", help="Filter by severity: critical, high, medium, low, info"),
):
    banner("Scan Results")

    query = ScanResult.query
    if target:
        db_target = Target.query.filter(
            (Target.name == target) | (Target.domain == target) | (Target.id == int(target) if target.isdigit() else -1)
        ).first()
        if db_target:
            query = query.filter_by(target_id=db_target.id)
        else:
            console.print("[red]Target not found[/red]")
            return

    if scan_id:
        query = query.filter_by(scan_id=scan_id)
    if severity:
        query = query.filter_by(severity=severity)

    results = query.order_by(ScanResult.created_at.desc()).limit(config.max_table_rows).all()
    if not results:
        console.print("[yellow]No results found.[/yellow]")
        return

    if format == "detailed":
        for r in results:
            panel = Panel(
                f"[bold]Type:[/bold] {r.finding_type}\n"
                f"[bold]URL:[/bold] {r.url or 'N/A'}\n"
                f"[bold]Evidence:[/bold] {r.evidence or 'N/A'}\n"
                f"[bold]Payload:[/bold] {r.payload or 'N/A'}\n"
                f"[bold]Parameter:[/bold] {r.parameter or 'N/A'}",
                title=f"[bold {'red' if r.severity == 'critical' else 'yellow' if r.severity == 'high' else 'cyan'}]"
                      f"{r.severity.upper()}[/bold {'red' if r.severity == 'critical' else 'yellow' if r.severity == 'high' else 'cyan'}] "
                      f"{r.finding_type}",
                border_style="red" if r.severity == "critical" else "yellow" if r.severity == "high" else "blue",
            )
            console.print(panel)
    else:
        console.print(result_table(results, title="Findings"))
