import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn
from datetime import datetime, timezone
import asyncio

from core.db import db, Target, Scan
from core.engine import engine
from core.config import config
from cli.ui.panels import banner
from cli.ui.tables import result_table
from cli.ui.progress import scan_progress

app = typer.Typer(help="Run a full scan on a target")
console = Console()


@app.callback()
def main():
    pass


@app.command()
def run(
    target: str = typer.Argument(..., help="Target domain, IP, or URL"),
    modules: str = typer.Option("all", "--modules", "-m", help="Comma-separated modules or 'all'"),
):
    banner("PHANTOM Scan Engine")
    from core.utils import normalize_target
    val, ttype = normalize_target(target)

    db_target = Target(
        name=val,
        domain=val if ttype == "domain" else None,
        ip=val if ttype == "ip" else None,
        type=ttype,
        status="new",
    )
    db.session.add(db_target)
    db.session.commit()

    if modules == "all":
        mod_list = engine.list_modules()
    else:
        mod_list = [m.strip() for m in modules.split(",")]
        mod_list = [m for m in mod_list if engine.get_module(m)]

    scan = Scan(
        target_id=db_target.id,
        modules=",".join(mod_list),
        status="pending",
        triggered_by="cli",
    )
    db.session.add(scan)
    db.session.commit()

    info_table = Table.grid(padding=(0, 2))
    info_table.add_column(style="bold cyan")
    info_table.add_column(style="white")
    info_table.add_row("Target", val)
    info_table.add_row("Type", ttype)
    info_table.add_row("Modules", str(len(mod_list)))
    info_table.add_row("Scan ID", str(scan.id))
    console.print(Panel(info_table, title="[bold]Scan Configuration[/bold]", border_style="blue"))

    asyncio.run(engine.run_scan(scan.id, mod_list))

    results = db_target.scans.order_by(Scan.id.desc()).first().results.all()
    console.print(result_table([r for r in results], title="Scan Results"))
