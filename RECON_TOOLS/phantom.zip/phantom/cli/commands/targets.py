import typer
from rich.console import Console
from rich.table import Table
from rich.prompt import Prompt, Confirm
from rich.panel import Panel

from core.db import db, Target
from cli.ui.panels import banner

app = typer.Typer(help="Manage targets")
console = Console()


@app.callback()
def main():
    pass


@app.command()
def list():
    banner("Targets")
    targets = Target.query.all()
    if not targets:
        console.print("[yellow]No targets found.[/yellow]")
        return

    table = Table(show_header=True, header_style="bold cyan")
    table.add_column("ID", style="dim")
    table.add_column("Name")
    table.add_column("Domain/IP")
    table.add_column("Type")
    table.add_column("Status")
    table.add_column("Created")

    for t in targets:
        table.add_row(
            str(t.id),
            t.name,
            t.domain or t.ip or "",
            t.type,
            t.status,
            t.created_at.strftime("%Y-%m-%d") if t.created_at else "",
        )
    console.print(table)


@app.command()
def add(
    name: str = typer.Argument(..., help="Target name"),
    domain: str = typer.Option("", "--domain", "-d", help="Domain name"),
    ip: str = typer.Option("", "--ip", help="IP address"),
):
    from core.utils import is_valid_domain, is_valid_ip
    ttype = "domain" if domain else "ip" if ip else "domain"
    target = Target(name=name, domain=domain or name, ip=ip, type=ttype, status="new")
    db.session.add(target)
    db.session.commit()
    console.print(f"[green]Target '{name}' added (ID: {target.id})[/green]")


@app.command()
def delete(
    target_id: int = typer.Argument(..., help="Target ID"),
):
    target = db.session.get(Target, target_id)
    if not target:
        console.print("[red]Target not found[/red]")
        return
    if Confirm.ask(f"Delete target '{target.name}' (ID: {target_id})?"):
        db.session.delete(target)
        db.session.commit()
        console.print(f"[green]Target {target_id} deleted[/green]")
