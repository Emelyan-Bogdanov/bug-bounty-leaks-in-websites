import typer
from rich.console import Console
import asyncio

from core.db import db, Target, Scan
from core.engine import engine
from cli.ui.panels import banner
from cli.ui.tables import result_table

app = typer.Typer(help="Fuzz a target URL")
console = Console()


@app.callback()
def main():
    pass


@app.command()
def run(
    url: str = typer.Argument(..., help="URL to fuzz"),
    wordlist: str = typer.Option("", "--wordlist", "-w", help="Custom wordlist path"),
    threads: int = typer.Option(50, "--threads", "-t", help="Thread count"),
):
    banner("PHANTOM Fuzzer")
    from core.utils import normalize_target
    val, ttype = normalize_target(url)

    db_target = Target(name=val, url=val, type="url", status="new")
    db.session.add(db_target)
    db.session.commit()

    mod_list = ["fuzzing.dir_fuzzer", "fuzzing.param_fuzzer", "fuzzing.vhost_fuzzer", "fuzzing.api_fuzzer"]
    scan = Scan(target_id=db_target.id, modules=",".join(mod_list), status="pending", triggered_by="cli")
    db.session.add(scan)
    db.session.commit()

    asyncio.run(engine.run_scan(scan.id, mod_list))
    results = db_target.scans.order_by(Scan.id.desc()).first().results.all()
    console.print(result_table([r for r in results], title="Fuzzing Results"))
