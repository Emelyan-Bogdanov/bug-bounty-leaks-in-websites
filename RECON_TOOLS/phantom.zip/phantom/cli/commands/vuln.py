import typer
from rich.console import Console
from rich.panel import Panel
import asyncio

from core.db import db, Target, Scan
from core.engine import engine
from cli.ui.panels import banner
from cli.ui.tables import result_table

app = typer.Typer(help="Run vulnerability scans on a target")
console = Console()


@app.callback()
def main():
    pass


@app.command()
def run(
    target: str = typer.Argument(..., help="Target domain or URL"),
    modules: str = typer.Option("all", "--modules", "-m", help="Comma-separated vuln modules"),
):
    banner("PHANTOM Vulnerability Scanner")
    from core.utils import normalize_target
    val, ttype = normalize_target(target)

    db_target = Target(name=val, domain=val, type=ttype, status="new")
    db.session.add(db_target)
    db.session.commit()

    if modules == "all":
        mod_list = [m for m in engine.list_modules("vuln")]
        mod_list += [m for m in engine.list_modules("headers")]
    else:
        mod_list = [f"vuln.{m.strip()}" for m in modules.split(",") if engine.get_module(f"vuln.{m.strip()}")]

    scan = Scan(target_id=db_target.id, modules=",".join(mod_list), status="pending", triggered_by="cli")
    db.session.add(scan)
    db.session.commit()

    asyncio.run(engine.run_scan(scan.id, mod_list))
    results = db_target.scans.order_by(Scan.id.desc()).first().results.all()
    console.print(result_table([r for r in results], title="Vulnerability Results"))
