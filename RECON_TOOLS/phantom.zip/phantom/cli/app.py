import typer
from rich.console import Console
from rich.panel import Panel
from rich import print as rprint
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.config import config
from cli.commands import scan, recon, vuln, fuzz, report, targets, results

app = typer.Typer(
    name="phantom",
    help="PHANTOM — Web Reconnaissance & Penetration Testing Platform",
    no_args_is_help=True,
    rich_markup_mode="rich",
)

console = Console()


@app.callback()
def main():
    pass


@app.command()
def version():
    rprint(f"[bold cyan]PHANTOM[/bold cyan] [white]v{config.version}[/white]")


@app.command()
def interactive():
    from rich.prompt import Prompt
    from rich.panel import Panel
    from rich.rule import Rule

    console.print(Panel.fit(
        "[bold cyan]PHANTOM[/bold cyan] — Interactive Scan Wizard",
        border_style="cyan",
    ))
    target = Prompt.ask("[bold]Target[/bold]")
    mode = Prompt.ask("[bold]Mode[/bold]", choices=["full", "recon", "vuln", "fuzz"], default="full")
    console.print(Rule())

    if mode == "full":
        scan.scan_target(target, modules="all")
    elif mode == "recon":
        recon.recon_target(target)
    elif mode == "vuln":
        vuln.vuln_target(target)
    elif mode == "fuzz":
        url = Prompt.ask("[bold]URL to fuzz[/bold]")
        fuzz.fuzz_target(url)


app.add_typer(scan.app, name="scan", help="Run a full scan on a target")
app.add_typer(recon.app, name="recon", help="Run recon modules on a target")
app.add_typer(vuln.app, name="vuln", help="Run vulnerability scans on a target")
app.add_typer(fuzz.app, name="fuzz", help="Fuzz a target URL")
app.add_typer(report.app, name="report", help="Generate reports")
app.add_typer(targets.app, name="targets", help="Manage targets")
app.add_typer(results.app, name="results", help="View scan results")


if __name__ == "__main__":
    app()
