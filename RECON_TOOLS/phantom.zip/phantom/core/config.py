import os
from pathlib import Path
import yaml
from dotenv import load_dotenv


class Config:
    def __init__(self):
        self.root = Path(__file__).resolve().parent.parent
        load_dotenv(self.root / ".env")
        self._raw = self._load_yaml()
        self._parse()

    def _load_yaml(self) -> dict:
        path = self.root / "config.yaml"
        if path.exists():
            with open(path) as f:
                return yaml.safe_load(f) or {}
        return {}

    def _parse(self):
        p = self._raw.get("platform", {})
        self.name = p.get("name", "PHANTOM")
        self.version = p.get("version", "1.0")
        self.debug = p.get("debug", False)

        srv = self._raw.get("server", {})
        self.host = srv.get("host", "0.0.0.0")
        self.port = srv.get("port", 5000)

        db = self._raw.get("database", {})
        self.database_url = db.get("url", "sqlite:///phantom.db")

        sc = self._raw.get("scanner", {})
        self.default_threads = sc.get("default_threads", 50)
        self.request_timeout = sc.get("request_timeout", 10)
        self.max_depth = sc.get("max_depth", 3)
        self.user_agent = sc.get("user_agent", "Mozilla/5.0 (compatible; PHANTOM/1.0)")
        self.follow_redirects = sc.get("follow_redirects", True)
        self.verify_ssl = sc.get("verify_ssl", False)

        rl = self._raw.get("rate_limiting", {})
        self.requests_per_second = rl.get("requests_per_second", 20)
        self.delay_between_modules = rl.get("delay_between_modules", 0.5)

        wl = self._raw.get("wordlists", {})
        self.wordlists = {
            "directories": self.root / wl.get("directories", "data/wordlists/dirs-medium.txt"),
            "subdomains": self.root / wl.get("subdomains", "data/wordlists/subdomains-top10k.txt"),
            "parameters": self.root / wl.get("parameters", "data/wordlists/params-common.txt"),
        }

        keys = self._raw.get("api_keys", {})
        self.api_keys = {
            "shodan": keys.get("shodan", "") or os.getenv("SHODAN_API_KEY", ""),
            "virustotal": keys.get("virustotal", "") or os.getenv("VIRUSTOTAL_API_KEY", ""),
            "hunter_io": keys.get("hunter_io", "") or os.getenv("HUNTER_IO_API_KEY", ""),
            "censys_id": keys.get("censys_id", "") or os.getenv("CENSYS_API_ID", ""),
            "censys_secret": keys.get("censys_secret", "") or os.getenv("CENSYS_API_SECRET", ""),
        }

        cli = self._raw.get("cli", {})
        self.rich_theme = cli.get("rich_theme", "dark")
        self.progress_refresh_rate = cli.get("progress_refresh_rate", 4)
        self.stream_buffer_size = cli.get("stream_buffer_size", 1024)
        self.max_table_rows = cli.get("max_table_rows", 100)


config = Config()
