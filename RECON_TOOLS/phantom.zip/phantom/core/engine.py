import asyncio
import importlib
import time
from datetime import datetime, timezone
from typing import Optional

from .config import config
from .db import db, Scan, ScanResult, ScanStatus
from .logger import logger


class Engine:
    def __init__(self):
        self._tasks: dict[int, asyncio.Task] = {}
        self._semaphore = asyncio.Semaphore(config.default_threads)
        self._modules = self._discover_modules()

    def _discover_modules(self) -> dict:
        categories = {
            "recon": [
                "dns", "whois", "subdomain", "port_scanner", "banner_grabber",
                "tech_detect", "web_crawler", "screenshot", "asn_lookup",
                "cert_transparency", "google_dorking", "shodan_api", "wayback",
                "email_harvest",
            ],
            "vuln": [
                "sqli", "xss", "lfi_rfi", "ssrf", "open_redirect", "idor",
                "csrf", "cmd_injection", "ssti", "xxe", "cors", "auth_bypass",
                "cve_lookup",
            ],
            "headers": [
                "security_headers", "cookie_analyzer", "ssl_tls",
            ],
            "fuzzing": [
                "dir_fuzzer", "param_fuzzer", "vhost_fuzzer", "api_fuzzer",
            ],
            "reporting": [
                "pdf_report", "html_report", "csv_export", "json_export",
            ],
        }
        modules = {}
        for category, names in categories.items():
            for name in names:
                try:
                    mod_path = f"modules.{category}.{name}"
                    mod = importlib.import_module(mod_path)
                    modules[f"{category}.{name}"] = mod
                except ImportError:
                    logger.warning(f"Module {category}.{name} not available")
        return modules

    def get_module(self, name: str):
        return self._modules.get(name)

    def list_modules(self, category: Optional[str] = None) -> list[str]:
        if category:
            return [m for m in self._modules if m.startswith(f"{category}.")]
        return list(self._modules.keys())

    async def run_scan(self, scan_id: int, modules: list[str]):
        scan = db.session.get(Scan, scan_id)
        if not scan:
            return

        scan.status = ScanStatus.RUNNING.value
        scan.started_at = datetime.now(timezone.utc)
        db.session.commit()

        target = scan.target
        logger.info(f"Starting scan {scan_id} on {target.name or target.domain} [{', '.join(modules)}]")

        start = time.monotonic()
        for mod_name in modules:
            mod = self.get_module(mod_name)
            if not mod:
                logger.warning(f"Module {mod_name} skipped — not found")
                continue

            logger.info(f"[{mod_name}] running...")
            try:
                async with self._semaphore:
                    runner = getattr(mod, "run", None)
                    if runner:
                        if asyncio.iscoroutinefunction(runner):
                            results = await runner(target.domain or target.ip, scan.id)
                        else:
                            results = runner(target.domain or target.ip, scan.id)
                        self._store_results(scan_id, target.id, mod_name, results or [])
                    await asyncio.sleep(config.delay_between_modules)
            except Exception as e:
                logger.error(f"[{mod_name}] failed: {e}")

        elapsed = time.monotonic() - start
        scan.status = ScanStatus.COMPLETED.value
        scan.finished_at = datetime.now(timezone.utc)
        db.session.commit()
        logger.info(f"Scan {scan_id} completed in {elapsed:.1f}s")

    def _store_results(self, scan_id: int, target_id: int, module: str, results: list[dict]):
        for r in results:
            result = ScanResult(
                scan_id=scan_id,
                target_id=target_id,
                module=module,
                finding_type=r.get("finding_type"),
                severity=r.get("severity", "info"),
                url=r.get("url"),
                parameter=r.get("parameter"),
                payload=r.get("payload"),
                evidence=r.get("evidence"),
                raw_output=r.get("raw_output"),
            )
            db.session.add(result)
        db.session.commit()

    def start_scan(self, scan_id: int, modules: list[str]):
        task = asyncio.ensure_future(self.run_scan(scan_id, modules))
        self._tasks[scan_id] = task
        return task

    def cancel_scan(self, scan_id: int):
        task = self._tasks.get(scan_id)
        if task and not task.done():
            task.cancel()
            scan = db.session.get(Scan, scan_id)
            if scan:
                scan.status = ScanStatus.CANCELLED.value
                db.session.commit()
            return True
        return False


engine = Engine()
