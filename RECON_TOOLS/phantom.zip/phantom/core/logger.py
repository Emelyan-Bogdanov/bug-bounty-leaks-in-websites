import logging
import sys
from pathlib import Path

from rich.console import Console
from rich.logging import RichHandler

from .config import config


class Logger:
    def __init__(self):
        self.console = Console(theme=config.rich_theme)
        self._setup_file_handler()
        self._setup_rich_handler()

    def _setup_file_handler(self):
        log_dir = Path(config.root) / "logs"
        log_dir.mkdir(exist_ok=True)
        fh = logging.FileHandler(log_dir / "phantom.log")
        fh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s"))
        fh.setLevel(logging.DEBUG if config.debug else logging.INFO)

        root = logging.getLogger()
        root.setLevel(logging.DEBUG if config.debug else logging.INFO)
        root.addHandler(fh)

    def _setup_rich_handler(self):
        rh = RichHandler(
            console=self.console,
            show_time=True,
            show_path=False,
            rich_tracebacks=True,
            tracebacks_show_locals=config.debug,
        )
        rh.setLevel(logging.INFO)
        logging.getLogger().addHandler(rh)

    def get(self, name: str) -> logging.Logger:
        return logging.getLogger(name)

    def debug(self, msg: str, *args, **kwargs):
        self.console.log(f"[dim]{msg}[/dim]", *args, **kwargs)

    def info(self, msg: str, *args, **kwargs):
        self.console.log(f"[cyan]{msg}[/cyan]", *args, **kwargs)

    def warning(self, msg: str, *args, **kwargs):
        self.console.log(f"[yellow]{msg}[/yellow]", *args, **kwargs)

    def error(self, msg: str, *args, **kwargs):
        self.console.log(f"[red]{msg}[/red]", *args, **kwargs)

    def critical(self, msg: str, *args, **kwargs):
        self.console.log(f"[bold red]{msg}[/bold red]", *args, **kwargs)


logger = Logger()
