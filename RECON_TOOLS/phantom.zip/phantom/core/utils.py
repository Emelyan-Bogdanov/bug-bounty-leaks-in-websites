import re
import ipaddress
from typing import Optional


DOMAIN_RE = re.compile(
    r"^(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$"
)
IP_RE = re.compile(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$")
URL_RE = re.compile(r"^https?://[^\s/$.?#].[^\s]*$", re.IGNORECASE)


def is_valid_domain(domain: str) -> bool:
    return bool(DOMAIN_RE.match(domain))


def is_valid_ip(ip: str) -> bool:
    try:
        ipaddress.ip_address(ip)
        return True
    except ValueError:
        return False


def is_valid_url(url: str) -> bool:
    return bool(URL_RE.match(url))


def normalize_target(value: str) -> tuple[str, str]:
    value = value.strip().lower()
    if is_valid_ip(value):
        return value, "ip"
    if is_valid_domain(value):
        return value, "domain"
    if is_valid_url(value):
        return value, "url"
    try:
        ipaddress.ip_network(value, strict=False)
        return value, "cidr"
    except ValueError:
        pass
    return value, "unknown"


def deduplicate(entries: list[dict], key: str = "url") -> list[dict]:
    seen = set()
    result = []
    for entry in entries:
        val = entry.get(key)
        if val and val not in seen:
            seen.add(val)
            result.append(entry)
    return result


def extract_domain_from_url(url: str) -> Optional[str]:
    m = re.search(r"https?://([^/]+)", url)
    if m:
        return m.group(1).split(":")[0]
    return None


def extract_base_domain(domain: str) -> Optional[str]:
    parts = domain.split(".")
    if len(parts) >= 2:
        return ".".join(parts[-2:])
    return domain


def severity_score(severity: str) -> int:
    return {"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0}.get(severity, 0)
