import subprocess
import shlex
import json
from datetime import datetime, timezone
from flask import (
    Blueprint, render_template, request, jsonify
)
from flask_login import login_required, current_user
from app.models import Target, ScanResult
from app import db

tools_bp = Blueprint(
    'tools', __name__, template_folder='../../templates/tools'
)

ALLOWED_TOOLS = {
    'whois': ['whois'],
    'nslookup': ['nslookup'],
    'ping': ['ping', '-c', '4'],
    'traceroute': ['traceroute'],
    'dig': ['dig'],
}


def sanitise_input(user_input):
    allowed_chars = set(
        'abcdefghijklmnopqrstuvwxyz'
        'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
        '0123456789.-_:/'
    )
    return ''.join(c for c in user_input if c in allowed_chars)


@tools_bp.route('/')
@login_required
def runner():
    targets = Target.query.filter_by(
        user_id=current_user.id, status='active'
    ).order_by(Target.name).all()
    return render_template('tools/runner.html', targets=targets, tools=list(ALLOWED_TOOLS.keys()))


@tools_bp.route('/run', methods=['POST'])
@login_required
def run_tool():
    tool = request.form.get('tool', '').strip().lower()
    target_input = request.form.get('target', '').strip()
    target_id = request.form.get('target_id', '').strip()

    if tool not in ALLOWED_TOOLS:
        return jsonify({'error': f'Tool "{tool}" not allowed.'}), 400

    if not target_input:
        return jsonify({'error': 'Target input is required.'}), 400

    safe_input = sanitise_input(target_input)
    if not safe_input:
        return jsonify({'error': 'Invalid target input.'}), 400

    cmd = ALLOWED_TOOLS[tool] + [safe_input]

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=10
        )
        output = result.stdout + result.stderr
        if not output.strip():
            output = f'[No output returned from {tool}]'
    except subprocess.TimeoutExpired:
        output = f'[ERROR] {tool} timed out after 10 seconds.'
    except FileNotFoundError:
        output = f'[ERROR] {tool} is not installed on this system.'
    except Exception as e:
        output = f'[ERROR] {str(e)}'

    saved_id = None
    if target_id:
        try:
            tid = int(target_id)
            target = Target.query.filter_by(
                id=tid, user_id=current_user.id
            ).first()
            if target:
                parsed = {
                    'tool': tool,
                    'target': safe_input,
                    'timestamp': datetime.now(timezone.utc).isoformat(),
                }
                scan = ScanResult(
                    target_id=tid,
                    tool_name=tool,
                    raw_output=output,
                    parsed_output=json.dumps(parsed),
                )
                db.session.add(scan)
                db.session.commit()
                saved_id = scan.id
        except (ValueError, Exception):
            pass

    return jsonify({
        'output': output,
        'saved_id': saved_id,
        'tool': tool,
        'target': safe_input,
    })
