from flask import Blueprint, render_template
from flask_login import login_required, current_user
from app.models import Target, ScanResult, Note
from app import db

dashboard_bp = Blueprint(
    'dashboard', __name__, template_folder='../templates/dashboard'
)


@dashboard_bp.route('/')
@login_required
def index():
    total_targets = Target.query.filter_by(
        user_id=current_user.id
    ).count()

    total_scans = ScanResult.query.join(Target).filter(
        Target.user_id == current_user.id
    ).count()

    total_notes = Note.query.join(Target).filter(
        Target.user_id == current_user.id
    ).count()

    last_scan = ScanResult.query.join(Target).filter(
        Target.user_id == current_user.id
    ).order_by(ScanResult.created_at.desc()).first()

    last_scan_str = None
    if last_scan:
        last_scan_str = last_scan.created_at.strftime('%Y-%m-%d %H:%M')

    recent_targets = Target.query.filter_by(
        user_id=current_user.id
    ).order_by(Target.created_at.desc()).limit(5).all()

    recent_scans = ScanResult.query.join(Target).filter(
        Target.user_id == current_user.id
    ).order_by(ScanResult.created_at.desc()).limit(5).all()

    return render_template(
        'dashboard/index.html',
        total_targets=total_targets,
        total_scans=total_scans,
        total_notes=total_notes,
        last_scan=last_scan_str,
        recent_targets=recent_targets,
        recent_scans=recent_scans,
    )
