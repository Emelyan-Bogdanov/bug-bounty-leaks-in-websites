from datetime import datetime, timezone
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from app import db


class User(UserMixin, db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(256), nullable=False)
    created_at = db.Column(
        db.DateTime, nullable=False,
        default=lambda: datetime.now(timezone.utc)
    )

    targets = db.relationship('Target', backref='owner', lazy='dynamic')
    notes = db.relationship('Note', backref='author', lazy='dynamic')

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class Target(db.Model):
    __tablename__ = 'targets'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False, index=True)
    domain_ip = db.Column(db.String(255), nullable=False)
    target_type = db.Column(
        db.String(20), nullable=False, default='domain'
    )
    status = db.Column(
        db.String(20), nullable=False, default='active'
    )
    description = db.Column(db.Text, default='')
    notes_count = db.Column(db.Integer, default=0)
    created_at = db.Column(
        db.DateTime, nullable=False,
        default=lambda: datetime.now(timezone.utc)
    )
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)

    scan_results = db.relationship(
        'ScanResult', backref='target', lazy='dynamic',
        cascade='all, delete-orphan'
    )
    notes = db.relationship(
        'Note', backref='target_ref', lazy='dynamic',
        cascade='all, delete-orphan'
    )

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'domain_ip': self.domain_ip,
            'target_type': self.target_type,
            'status': self.status,
            'description': self.description,
            'notes_count': self.notes_count,
            'created_at': self.created_at.isoformat(),
            'user_id': self.user_id,
        }


class ScanResult(db.Model):
    __tablename__ = 'scan_results'

    id = db.Column(db.Integer, primary_key=True)
    target_id = db.Column(
        db.Integer, db.ForeignKey('targets.id'), nullable=False, index=True
    )
    tool_name = db.Column(db.String(80), nullable=False)
    raw_output = db.Column(db.Text, default='')
    parsed_output = db.Column(db.Text, default='{}')
    created_at = db.Column(
        db.DateTime, nullable=False,
        default=lambda: datetime.now(timezone.utc)
    )

    def to_dict(self):
        return {
            'id': self.id,
            'target_id': self.target_id,
            'tool_name': self.tool_name,
            'raw_output': self.raw_output,
            'parsed_output': self.parsed_output,
            'created_at': self.created_at.isoformat(),
            'target_name': self.target.name if self.target else '',
        }


class Note(db.Model):
    __tablename__ = 'notes'

    id = db.Column(db.Integer, primary_key=True)
    target_id = db.Column(
        db.Integer, db.ForeignKey('targets.id'), nullable=False, index=True
    )
    user_id = db.Column(
        db.Integer, db.ForeignKey('users.id'), nullable=False
    )
    content = db.Column(db.Text, nullable=False, default='')
    created_at = db.Column(
        db.DateTime, nullable=False,
        default=lambda: datetime.now(timezone.utc)
    )
    updated_at = db.Column(
        db.DateTime, nullable=False,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc)
    )

    def to_dict(self):
        return {
            'id': self.id,
            'target_id': self.target_id,
            'user_id': self.user_id,
            'content': self.content,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat(),
            'author': self.author.username if self.author else '',
            'target_name': self.target_ref.name if self.target_ref else '',
        }
