import csv
import io
import json
from datetime import datetime, timezone
from flask import (
    Blueprint, render_template, request, Response, jsonify
)
from flask_login import login_required, current_user
from app.models import Target, ScanResult, Note

export_bp = Blueprint('export', __name__)


@export_bp.route('/csv/<int:target_id>')
@login_required
def export_csv(target_id):
    target = Target.query.filter_by(
        id=target_id, user_id=current_user.id
    ).first_or_404()

    scans = target.scan_results.order_by(ScanResult.created_at.desc()).all()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['tool_name', 'target', 'timestamp', 'raw_output', 'parsed_output'])

    for scan in scans:
        parsed = scan.parsed_output
        ts = scan.created_at.strftime('%Y-%m-%d %H:%M:%S UTC')
        writer.writerow([
            scan.tool_name,
            target.domain_ip,
            ts,
            scan.raw_output,
            parsed,
        ])

    csv_bytes = output.getvalue().encode('utf-8')

    return Response(
        csv_bytes,
        mimetype='text/csv',
        headers={
            'Content-Disposition': (
                f'attachment; filename=results_{target.name}_{datetime.now(timezone.utc).strftime("%Y%m%d")}.csv'
            ),
            'Content-Type': 'text/csv; charset=utf-8',
        }
    )


@export_bp.route('/pdf/<int:target_id>')
@login_required
def export_pdf(target_id):
    target = Target.query.filter_by(
        id=target_id, user_id=current_user.id
    ).first_or_404()

    scans = target.scan_results.order_by(ScanResult.created_at.desc()).all()
    notes = target.notes.order_by(Note.created_at.desc()).all()

    html = _build_pdf_html(target, scans, notes)

    try:
        from weasyprint import HTML
        pdf_bytes = HTML(string=html).write_pdf()
    except Exception:
        return Response(
            '<html><body><h2>PDF generation requires WeasyPrint.</h2>'
            '<p>Install it: pip install weasyprint</p>'
            '<pre>' + html.replace('<', '&lt;') + '</pre></body></html>',
            mimetype='text/html',
        )

    return Response(
        pdf_bytes,
        mimetype='application/pdf',
        headers={
            'Content-Disposition': (
                f'attachment; filename=report_{target.name}_{datetime.now(timezone.utc).strftime("%Y%m%d")}.pdf'
            ),
        }
    )


@export_bp.route('/export-format/<int:target_id>')
@login_required
def export_format(target_id):
    target = Target.query.filter_by(
        id=target_id, user_id=current_user.id
    ).first_or_404()

    scans = target.scan_results.order_by(ScanResult.created_at.desc()).all()

    export_data = []
    for scan in scans:
        export_data.append({
            'tool_name': scan.tool_name,
            'target': target.domain_ip,
            'timestamp': scan.created_at.isoformat(),
            'raw_output': scan.raw_output,
            'parsed_output': scan.parsed_output,
        })

    return Response(
        json.dumps(export_data, indent=2),
        mimetype='application/json',
        headers={
            'Content-Disposition': (
                f'attachment; filename=results_{target.name}_{datetime.now(timezone.utc).strftime("%Y%m%d")}.json'
            ),
        }
    )


def _build_pdf_html(target, scans, notes):
    scan_rows = ''
    for s in scans:
        ts = s.created_at.strftime('%Y-%m-%d %H:%M:%S UTC')
        out_escaped = s.raw_output.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
        scan_rows += f'''
        <tr>
            <td>{s.tool_name}</td>
            <td>{ts}</td>
            <td><pre style="font-size:11px;background:#1e1e1e;color:#d4d4d4;padding:8px;border-radius:4px;max-height:200px;overflow:auto;">{out_escaped}</pre></td>
        </tr>'''

    note_items = ''
    for n in notes:
        ts = n.created_at.strftime('%Y-%m-%d %H:%M:%S')
        content_escaped = n.content.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
        note_items += f'<li><strong>{ts}</strong> — {content_escaped}</li>'

    html = f'''<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>Recon Report — {target.name}</title>
<style>
body {{ font-family: 'Segoe UI', Arial, sans-serif; background: #fff; color: #222; margin: 30px; }}
h1 {{ color: #0f1117; border-bottom: 2px solid #4f8ef7; padding-bottom: 8px; }}
h2 {{ color: #1c1f26; margin-top: 30px; }}
table {{ width: 100%; border-collapse: collapse; margin: 16px 0; }}
th, td {{ padding: 10px 12px; text-align: left; border-bottom: 1px solid #ddd; }}
th {{ background: #4f8ef7; color: #fff; }}
tr:nth-child(even) {{ background: #f7f9fc; }}
.meta {{ color: #555; font-size: 14px; }}
pre {{ white-space: pre-wrap; word-break: break-word; }}
ul {{ padding-left: 20px; }}
li {{ margin: 8px 0; }}
</style></head>
<body>
<h1>Reconnaissance Report</h1>
<p class="meta"><strong>Target:</strong> {target.name} ({target.domain_ip})<br>
<strong>Type:</strong> {target.target_type} | <strong>Status:</strong> {target.status}<br>
<strong>Generated:</strong> {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}</p>
<p><strong>Description:</strong> {target.description or 'N/A'}</p>

<h2>Scan Results ({len(scans)})</h2>
<table>
<tr><th>Tool</th><th>Timestamp</th><th>Output</th></tr>
{scan_rows}
</table>

<h2>Notes ({len(notes)})</h2>
<ul>
{note_items or '<li>No notes recorded.</li>'}
</ul>
</body></html>'''
    return html
