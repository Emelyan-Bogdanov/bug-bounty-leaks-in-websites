from flask import (
    Blueprint, render_template, redirect, url_for,
    request, flash, jsonify
)
from flask_login import login_required, current_user
from app.models import Target, ScanResult, Note
from app import db
from datetime import datetime, timezone

targets_bp = Blueprint(
    'targets', __name__, template_folder='../../templates/targets'
)


@targets_bp.route('/')
@login_required
def list_targets():
    query = Target.query.filter_by(user_id=current_user.id)

    search = request.args.get('search', '').strip()
    type_filter = request.args.get('type', '').strip()

    if search:
        query = query.filter(
            Target.name.ilike(f'%{search}%') |
            Target.domain_ip.ilike(f'%{search}%')
        )
    if type_filter:
        query = query.filter_by(target_type=type_filter)

    targets = query.order_by(Target.created_at.desc()).all()
    return render_template(
        'targets/list.html',
        targets=targets,
        search=search,
        type_filter=type_filter
    )


@targets_bp.route('/add', methods=['POST'])
@login_required
def add_target():
    name = request.form.get('name', '').strip()
    domain_ip = request.form.get('domain_ip', '').strip()
    target_type = request.form.get('target_type', 'domain')
    description = request.form.get('description', '').strip()

    if not name or not domain_ip:
        flash('Name and domain/IP are required.', 'error')
        return redirect(url_for('targets.list_targets'))

    target = Target(
        name=name,
        domain_ip=domain_ip,
        target_type=target_type,
        description=description,
        user_id=current_user.id
    )
    db.session.add(target)
    db.session.commit()
    flash(f'Target "{name}" added successfully.', 'success')
    return redirect(url_for('targets.list_targets'))


@targets_bp.route('/<int:target_id>')
@login_required
def detail(target_id):
    target = Target.query.filter_by(
        id=target_id, user_id=current_user.id
    ).first_or_404()

    scans = target.scan_results.order_by(
        ScanResult.created_at.desc()
    ).all()

    notes = target.notes.order_by(Note.created_at.desc()).all()

    return render_template(
        'targets/detail.html',
        target=target,
        scans=scans,
        notes=notes
    )


@targets_bp.route('/<int:target_id>/archive', methods=['POST'])
@login_required
def archive_target(target_id):
    target = Target.query.filter_by(
        id=target_id, user_id=current_user.id
    ).first_or_404()
    target.status = 'archived'
    db.session.commit()
    flash(f'Target "{target.name}" archived.', 'info')
    return redirect(url_for('targets.list_targets'))


@targets_bp.route('/<int:target_id>/activate', methods=['POST'])
@login_required
def activate_target(target_id):
    target = Target.query.filter_by(
        id=target_id, user_id=current_user.id
    ).first_or_404()
    target.status = 'active'
    db.session.commit()
    flash(f'Target "{target.name}" activated.', 'success')
    return redirect(url_for('targets.list_targets'))


@targets_bp.route('/<int:target_id>/delete', methods=['POST'])
@login_required
def delete_target(target_id):
    target = Target.query.filter_by(
        id=target_id, user_id=current_user.id
    ).first_or_404()
    db.session.delete(target)
    db.session.commit()
    flash(f'Target "{target.name}" deleted.', 'info')
    return redirect(url_for('targets.list_targets'))


@targets_bp.route('/api/list')
@login_required
def api_list():
    targets = Target.query.filter_by(
        user_id=current_user.id, status='active'
    ).order_by(Target.name).all()
    return jsonify([t.to_dict() for t in targets])
