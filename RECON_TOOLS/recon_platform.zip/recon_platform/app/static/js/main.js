(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {

    /* ---- Sidebar ---- */
    var sidebar = document.getElementById('sidebar');
    var hamburger = document.getElementById('hamburger');
    var sidebarOverlay = document.getElementById('sidebarOverlay');

    if (hamburger) {
      hamburger.addEventListener('click', function () {
        sidebar.classList.add('open');
        if (sidebarOverlay) sidebarOverlay.classList.add('active');
      });
    }

    if (sidebarOverlay) {
      sidebarOverlay.addEventListener('click', function () {
        sidebar.classList.remove('open');
        sidebarOverlay.classList.remove('active');
      });
    }

    /* ---- Toasts auto-dismiss ---- */
    var toasts = document.querySelectorAll('[data-toast]');
    toasts.forEach(function (t) {
      setTimeout(function () {
        if (t.parentNode) {
          t.style.opacity = '0';
          t.style.transition = 'opacity 0.3s ease';
          setTimeout(function () { if (t.parentNode) t.parentNode.removeChild(t); }, 300);
        }
      }, 5000);
    });

    /* ---- Modal ---- */
    window.openModal = function (id) {
      var el = document.getElementById(id);
      if (el) el.classList.add('active');
    };

    window.closeModal = function (id) {
      var el = document.getElementById(id);
      if (el) el.classList.remove('active');
    };

    /* Close modal on overlay click */
    document.querySelectorAll('.modal-overlay').forEach(function (overlay) {
      overlay.addEventListener('click', function (e) {
        if (e.target === overlay) {
          overlay.classList.remove('active');
        }
      });
    });

    /* ---- Table Row Expansion ---- */
    window.toggleRowExpansion = function (id) {
      var row = document.getElementById('expanded-' + id);
      if (row) {
        var isHidden = row.style.display === 'none' || row.style.display === '';
        row.style.display = isHidden ? 'table-row' : 'none';
      }
    };

    /* ---- Dropdown ---- */
    window.toggleDropdown = function (id) {
      var menu = document.getElementById(id);
      if (menu) {
        var isActive = menu.classList.contains('active');
        closeAllDropdowns();
        if (!isActive) menu.classList.add('active');
      }
    };

    function closeAllDropdowns() {
      document.querySelectorAll('.dropdown-menu').forEach(function (m) {
        m.classList.remove('active');
      });
    }

    document.addEventListener('click', function (e) {
      if (!e.target.closest('.export-dropdown') && !e.target.closest('.import-dropdown')) {
        closeAllDropdowns();
      }
    });

    /* ---- Tool Runner ---- */
    var toolForm = document.getElementById('toolRunForm');
    var terminalOutput = document.getElementById('terminalOutput');
    var terminalHeader = document.getElementById('terminalHeader');
    var promptText = document.getElementById('promptText');
    var outputStatus = document.getElementById('outputStatus');
    var runBtn = document.getElementById('runToolBtn');
    var targetSelect = document.getElementById('targetSelect');
    var targetInput = document.getElementById('targetInput');

    if (targetSelect && targetInput) {
      targetSelect.addEventListener('change', function () {
        var selected = targetSelect.options[targetSelect.selectedIndex];
        if (selected && selected.value) {
          var text = selected.text;
          var ipMatch = text.match(/\(([^)]+)\)/);
          if (ipMatch) {
            targetInput.value = ipMatch[1];
          }
        }
      });
    }

    if (toolForm) {
      toolForm.addEventListener('submit', function (e) {
        e.preventDefault();

        var tool = document.getElementById('toolSelect').value;
        var target = targetInput.value.trim();
        var targetId = targetSelect ? targetSelect.value : '';

        if (!tool) {
          showToast('Please select a tool.', 'error');
          return;
        }

        if (!target) {
          showToast('Please enter a target domain or IP.', 'error');
          return;
        }

        var formData = new FormData();
        formData.append('tool', tool);
        formData.append('target', target);
        formData.append('target_id', targetId);

        runBtn.disabled = true;
        runBtn.innerHTML = '<span class="spinner"></span> Running...';
        if (outputStatus) outputStatus.textContent = 'Running...';
        if (promptText) promptText.textContent = 'Running ' + tool + ' on ' + target + '...';
        if (terminalHeader) terminalHeader.textContent = tool + ' — ' + target;

        appendToTerminal('$ ' + tool + ' ' + target + '\n');

        var xhr = new XMLHttpRequest();
        xhr.open('POST', '/tools/run', true);

        var csrfToken = getCSRFToken();

        if (csrfToken) {
          xhr.setRequestHeader('X-CSRFToken', csrfToken);
        }

        xhr.onload = function () {
          runBtn.disabled = false;
          runBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"/></svg>\n          Run Scan';

          if (xhr.status === 200) {
            var data = JSON.parse(xhr.responseText);
            appendToTerminal(data.output + '\n');
            if (outputStatus) outputStatus.textContent = 'Completed ' + (data.saved_id ? '(saved)' : '');
            if (promptText) promptText.textContent = 'Completed — ' + tool + ' on ' + target;
            scrollTerminal();
          } else {
            var errMsg = 'Error';
            try {
              var errData = JSON.parse(xhr.responseText);
              errMsg = errData.error || 'Request failed';
            } catch (_) {}
            appendToTerminal('[ERROR] ' + errMsg + '\n');
            if (outputStatus) outputStatus.textContent = 'Failed';
            if (promptText) promptText.textContent = 'Error — ' + errMsg;
            showToast(errMsg, 'error');
            scrollTerminal();
          }
        };

        xhr.onerror = function () {
          runBtn.disabled = false;
          runBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"/></svg>\n          Run Scan';
          appendToTerminal('[ERROR] Network error. Could not reach server.\n');
          if (outputStatus) outputStatus.textContent = 'Network Error';
          if (promptText) promptText.textContent = 'Network error';
          showToast('Network error. Is the server running?', 'error');
          scrollTerminal();
        };

        xhr.send(formData);
      });
    }

    function appendToTerminal(text) {
      if (terminalOutput) {
        terminalOutput.textContent += text;
        scrollTerminal();
      }
    }

    function scrollTerminal() {
      if (terminalOutput) {
        terminalOutput.scrollTop = terminalOutput.scrollHeight;
      }
    }

    /* ---- Clear Terminal ---- */
    window.clearOutput = function () {
      if (terminalOutput) terminalOutput.textContent = '';
      if (promptText) promptText.textContent = 'waiting for command...';
      if (terminalHeader) terminalHeader.textContent = 'Ready — select a tool and target, then run';
      if (outputStatus) outputStatus.textContent = '';
    };

    /* ---- CSRF Token ---- */
    function getCSRFToken() {
      var meta = document.querySelector('meta[name="csrf-token"]');
      if (meta) return meta.getAttribute('content');

      var name = 'csrf_token';
      var cookies = document.cookie.split(';');
      for (var i = 0; i < cookies.length; i++) {
        var c = cookies[i].trim();
        if (c.indexOf(name + '=') === 0) {
          return decodeURIComponent(c.substring(name.length + 1));
        }
      }
      return null;
    }

    /* ---- Toast (programmatic) ---- */
    window.showToast = function (message, type) {
      type = type || 'info';
      var mainContent = document.querySelector('.main-content');
      if (!mainContent) return;

      var toast = document.createElement('div');
      toast.className = 'toast toast-' + type;
      toast.setAttribute('data-toast', '');
      toast.innerHTML = '<span>' + escapeHtml(message) + '</span>' +
        '<button class="toast-close" onclick="this.parentElement.remove()">&times;</button>';

      mainContent.insertBefore(toast, mainContent.firstChild);

      setTimeout(function () {
        toast.style.opacity = '0';
        toast.style.transition = 'opacity 0.3s ease';
        setTimeout(function () { if (toast.parentNode) toast.parentNode.removeChild(toast); }, 300);
      }, 5000);
    };

    function escapeHtml(str) {
      var div = document.createElement('div');
      div.appendChild(document.createTextNode(str));
      return div.innerHTML;
    }

    /* ---- Note Edit ---- */
    window.editNote = function (noteId, content) {
      var modal = document.getElementById('editNoteModal');
      var form = document.getElementById('editNoteForm');
      var textarea = document.getElementById('editNoteContent');
      if (modal && form && textarea) {
        form.action = '/notes/' + noteId + '/edit';
        textarea.value = content;
        openModal('editNoteModal');
      }
    };
  });

})();
