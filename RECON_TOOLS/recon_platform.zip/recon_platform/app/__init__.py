from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_wtf.csrf import CSRFProtect
from config import Config

db = SQLAlchemy()
login_manager = LoginManager()
csrf = CSRFProtect()


def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    db.init_app(app)
    login_manager.init_app(app)
    csrf.init_app(app)

    login_manager.login_view = 'auth.login'
    login_manager.login_message_category = 'info'

    from app.models import User

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    from app.auth.routes import auth_bp
    from app.targets.routes import targets_bp
    from app.tools.routes import tools_bp
    from app.results.routes import results_bp
    from app.notes.routes import notes_bp
    from app.export.routes import export_bp
    from app.dashboard.routes import dashboard_bp

    app.register_blueprint(auth_bp, url_prefix='/auth')
    app.register_blueprint(targets_bp, url_prefix='/targets')
    app.register_blueprint(tools_bp, url_prefix='/tools')
    app.register_blueprint(results_bp, url_prefix='/results')
    app.register_blueprint(notes_bp, url_prefix='/notes')
    app.register_blueprint(export_bp, url_prefix='/export')
    app.register_blueprint(dashboard_bp, url_prefix='/dashboard')

    @app.errorhandler(404)
    def not_found(e):
        from flask import render_template
        return render_template('errors/404.html'), 404

    @app.errorhandler(500)
    def server_error(e):
        from flask import render_template
        return render_template('errors/500.html'), 500

    @app.route('/')
    def index():
        from flask import redirect, url_for
        from flask_login import current_user
        if current_user.is_authenticated:
            return redirect(url_for('dashboard.index'))
        return redirect(url_for('auth.login'))

    with app.app_context():
        import os
        instance_dir = os.path.join(app.instance_path)
        os.makedirs(instance_dir, exist_ok=True)
        db.create_all()

    return app
