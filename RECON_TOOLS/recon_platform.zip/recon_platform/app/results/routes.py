import csv
import io
import json
from datetime import datetime, timezone
from flask import (
    Blueprint, render_template, request, jsonify
)
from flask_login import login_required, current_user
from app.models import Target, ScanResult
from app import db

results_bp = Blueprint(
    'results', __name__, template_folder='../../templates/results'
)


@results_bp.route('/')
@login_required
def viewer():
    targets = Target.query.filter_by(
        user_id=current_user.id
    ).order_by(Target.name).all()

    query = ScanResult.query.join(Target).filter(
        Target.user_id == current_user.id
    )

    target_filter = request.args.get('target_id', '').strip()
    tool_filter = request.args.get('tool', '').strip()

    if target_filter:
        try:
            query = query.filter(ScanResult.target_id == int(target_filter))
        except ValueError:
            pass
    if tool_filter:
        query = query.filter(ScanResult.tool_name == tool_filter)

    results = query.order_by(ScanResult.created_at.desc()).all()
    tools_used = [
        r[0] for r in db.session.query(ScanResult.tool_name).distinct().all()
    ]

    return render_template(
        'results/viewer.html',
        results=results,
        targets=targets,
        tools_used=tools_used,
        target_filter=target_filter,
        tool_filter=tool_filter,
    )


@results_bp.route('/api/import', methods=['POST'])
@login_required
def import_results():
    target_id = request.form.get('target_id', '').strip()
    if not target_id:
        return jsonify({'error': 'target_id is required.'}), 400

    try:
        tid = int(target_id)
    except ValueError:
        return jsonify({'error': 'Invalid target_id.'}), 400

    target = Target.query.filter_by(
        id=tid, user_id=current_user.id
    ).first()
    if not target:
        return jsonify({'error': 'Target not found.'}), 404

    file = request.files.get('file')
    if not file:
        return jsonify({'error': 'No file provided.'}), 400

    filename = file.filename or ''
    imported = 0

    if filename.endswith('.csv'):
        stream = io.StringIO(file.stream.read().decode('utf-8'))
        reader = csv.DictReader(stream)
        for row in reader:
            tool_name = row.get('tool_name', 'unknown').strip()
            raw_output = row.get('raw_output', '')
            parsed_output = row.get('parsed_output', '{}')

            try:
                json.loads(parsed_output)
            except (json.JSONDecodeError, TypeError):
                parsed_output = json.dumps({
                    'tool': tool_name,
                    'imported_at': datetime.now(timezone.utc).isoformat(),
                })

            scan = ScanResult(
                target_id=tid,
                tool_name=tool_name,
                raw_output=raw_output,
                parsed_output=parsed_output,
            )
            db.session.add(scan)
            imported += 1
    elif filename.endswith('.json'):
        data = json.loads(file.stream.read().decode('utf-8'))
        if isinstance(data, dict):
            data = [data]
        for item in data:
            tool_name = item.get('tool_name', 'unknown').strip()
            raw_output = item.get('raw_output', '')
            parsed_output = item.get('parsed_output', '{}')
            try:
                json.loads(parsed_output)
            except (json.JSONDecodeError, TypeError):
                parsed_output = json.dumps({
                    'tool': tool_name,
                    'imported_at': datetime.now(timezone.utc).isoformat(),
                })
            scan = ScanResult(
                target_id=tid,
                tool_name=tool_name,
                raw_output=raw_output,
                parsed_output=parsed_output,
            )
            db.session.add(scan)
            imported += 1
    else:
        return jsonify({'error': 'Unsupported file format. Use .csv or .json.'}), 400

    db.session.commit()
    return jsonify({
        'message': f'Successfully imported {imported} result(s).',
        'imported': imported,
    })
