from datetime import datetime, timezone
from flask import (
    Blueprint, render_template, request, redirect,
    url_for, flash, jsonify
)
from flask_login import login_required, current_user
from app.models import Target, Note
from app import db

notes_bp = Blueprint(
    'notes', __name__, template_folder='../../templates/notes'
)


@notes_bp.route('/')
@login_required
def index():
    targets = Target.query.filter_by(
        user_id=current_user.id
    ).order_by(Target.name).all()

    target_filter = request.args.get('target_id', '').strip()

    query = Note.query.join(Target).filter(
        Target.user_id == current_user.id
    )

    if target_filter:
        try:
            query = query.filter(Note.target_id == int(target_filter))
        except ValueError:
            pass

    notes = query.order_by(Note.updated_at.desc()).all()
    return render_template(
        'notes/index.html',
        notes=notes,
        targets=targets,
        target_filter=target_filter,
    )


@notes_bp.route('/add', methods=['POST'])
@login_required
def add_note():
    target_id = request.form.get('target_id', '').strip()
    content = request.form.get('content', '').strip()

    if not target_id or not content:
        flash('Target and content are required.', 'error')
        return redirect(url_for('notes.index'))

    try:
        tid = int(target_id)
    except ValueError:
        flash('Invalid target.', 'error')
        return redirect(url_for('notes.index'))

    target = Target.query.filter_by(
        id=tid, user_id=current_user.id
    ).first()
    if not target:
        flash('Target not found.', 'error')
        return redirect(url_for('notes.index'))

    note = Note(
        target_id=tid,
        user_id=current_user.id,
        content=content
    )
    db.session.add(note)

    target.notes_count = Note.query.filter_by(target_id=tid).count() + 1
    db.session.commit()

    flash('Note added.', 'success')
    referrer = request.referrer or url_for('notes.index')
    return redirect(referrer)


@notes_bp.route('/<int:note_id>/edit', methods=['POST'])
@login_required
def edit_note(note_id):
    note = Note.query.get_or_404(note_id)
    target = Target.query.filter_by(
        id=note.target_id, user_id=current_user.id
    ).first()
    if not target:
        flash('Note not found.', 'error')
        return redirect(url_for('notes.index'))

    content = request.form.get('content', '').strip()
    if not content:
        flash('Content cannot be empty.', 'error')
        return redirect(url_for('notes.index'))

    note.content = content
    note.updated_at = datetime.now(timezone.utc)
    db.session.commit()

    flash('Note updated.', 'success')
    referrer = request.referrer or url_for('notes.index')
    return redirect(referrer)


@notes_bp.route('/<int:note_id>/delete', methods=['POST'])
@login_required
def delete_note(note_id):
    note = Note.query.get_or_404(note_id)
    target = Target.query.filter_by(
        id=note.target_id, user_id=current_user.id
    ).first()
    if not target:
        flash('Note not found.', 'error')
        return redirect(url_for('notes.index'))

    tid = note.target_id
    db.session.delete(note)
    target.notes_count = Note.query.filter_by(target_id=tid).count() - 1
    if target.notes_count < 0:
        target.notes_count = 0
    db.session.commit()

    flash('Note deleted.', 'info')
    referrer = request.referrer or url_for('notes.index')
    return redirect(referrer)
